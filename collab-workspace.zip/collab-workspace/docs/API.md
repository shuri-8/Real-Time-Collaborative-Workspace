# API

All endpoints are JSON, authenticated by the `cw_token` httpOnly cookie, and return `{ "error": "message" }` with an HTTP status on failure. A user with no access to a page gets **404**; insufficient role gets **403**.

## REST

### Auth
| Method | Path | Body | Notes |
|---|---|---|---|
| POST | `/api/auth/register` | `{name, email, password(≥8)}` | Creates user, personal workspace and first page, sets cookie |
| POST | `/api/auth/login` | `{email, password}` | Sets cookie |
| POST | `/api/auth/logout` | | Clears cookie |
| GET | `/api/auth/me` | | `{user}` |

### Workspaces and pages
| Method | Path | Body / Notes | Role |
|---|---|---|---|
| GET | `/api/workspaces` | Workspaces you own or belong to | any |
| POST | `/api/workspaces` | `{name}` → `{workspace, firstPageId}` | any |
| GET | `/api/workspaces/:id/pages` | Flat list of pages you can open, each with `role`, `canManage` | member |
| POST | `/api/workspaces/:id/pages` | `{title?, parentId?}` | workspace EDIT |
| GET | `/api/pages/:id` | `{page, role, canManage}` | VIEW |
| PATCH | `/api/pages/:id` | `{title?, icon?, parentId?, position?}` (cycle-checked) | EDIT |
| DELETE | `/api/pages/:id` | Cascades to children, comments, versions | owner / creator |

### Permissions
| Method | Path | Body | Role |
|---|---|---|---|
| GET | `/api/pages/:id/permissions` | `{people:[{userId,name,email,role,source}], canManage}` | VIEW |
| PUT | `/api/pages/:id/permissions` | `{email, role: VIEW|COMMENT|EDIT}` invite or change | owner / creator |
| DELETE | `/api/pages/:id/permissions?userId=` | | owner / creator |

Changes are pushed to live sockets through Redis (`refresh-perms`).

### Comments
| Method | Path | Body | Role |
|---|---|---|---|
| GET | `/api/pages/:id/comments` | flat list incl. replies (`parentId`) | VIEW |
| POST | `/api/pages/:id/comments` | `{body, quote?, anchorFrom?, anchorTo?, parentId?}` | COMMENT |
| PATCH | `/api/pages/:id/comments/:cid` | `{body?}` (author) / `{resolved?}` (author or EDIT) | COMMENT |
| DELETE | `/api/pages/:id/comments/:cid` | author or owner/creator | COMMENT |

`anchorFrom/anchorTo` are `Y.relativePositionToJSON` objects.

### Versions
| Method | Path | Notes | Role |
|---|---|---|---|
| GET | `/api/pages/:id/versions` | newest first, 100 max | VIEW |
| POST | `/api/pages/:id/versions` | `{label?}` manual snapshot (flushes live state first) | EDIT |
| GET | `/api/pages/:id/versions/:vid` | `{html}` escaped preview | VIEW |
| POST | `/api/pages/:id/versions/:vid/restore` | Saves "Before restore", then restores on the live doc (or the stored bytes if nobody is editing) | EDIT |

## WebSocket

`ws://host:4001|4002/<pageId>`. Authentication is the same cookie; `Origin` must be in `ALLOWED_ORIGINS`. Upgrade failures: `401` no/invalid token, `403` no access or bad origin, `404` unknown page. `GET /health` returns `{instanceId, rooms, connections, rssMb, heapUsedMb, messagesIn, rejected, ...}`.

All frames are binary and start with a lib0 `varUint` message type.

| Type | Name | Direction | Payload |
|---|---|---|---|
| 0 | SYNC | both | varUint subtype (0 step1 = state vector, 1 step2 = update, 2 update) + varUint8Array, per `y-protocols/sync` |
| 1 | AWARENESS | both | varUint8Array from `y-protocols/awareness` |
| 2 | AUTH | server → client | varString JSON `{"role":"EDIT"}`; sent on connect and whenever the role changes |
| 3 | DENIED | server → client | varString reason; a mutation was rejected |

Server rules: SYNC subtype 1 or 2 from a `VIEW`/`COMMENT` connection is dropped (+ `DENIED`). Malformed frames are ignored. Close code **4403** = access revoked (clients do not reconnect).

### Redis channels
* `doc:<pageId>`: lib0 `varString instanceId`, `varUint kind`, `varUint8Array payload`. Kinds: 0 UPDATE, 1 AWARENESS, 2 AWARENESS_QUERY, 3 SYNC_REQUEST (payload = state vector; answered with a diff UPDATE).
* `ctl`: JSON `{type: "flush" | "restore" | "refresh-perms", pageId, versionId?, opId}`. Acks are `SET ack:<opId>`.
* `rooms:<pageId>`: set of instance ids currently hosting the room.
