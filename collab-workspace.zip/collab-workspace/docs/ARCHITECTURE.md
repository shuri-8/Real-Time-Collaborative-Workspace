# Architecture

## Components

```mermaid
flowchart LR
  subgraph Browsers
    A[Tab A<br/>TipTap + Y.Doc]
    B[Tab B<br/>TipTap + Y.Doc]
  end
  A -- "REST + cookie" --> W[Next.js :3000]
  B -- "REST + cookie" --> W
  A == "WebSocket (binary Yjs)" ==> S1[ws-server-1 :4001]
  B == "WebSocket (binary Yjs)" ==> S2[ws-server-2 :4002]
  S1 <-- "Pub/Sub doc:pageId" --> R[(Redis)]
  S2 <-- "Pub/Sub doc:pageId" --> R
  W -- "ctl channel (restore, flush, perms)" --> R
  R -- ctl --> S1
  R -- ctl --> S2
  W --> P[(PostgreSQL)]
  S1 -- "debounced bytes" --> P
  S2 -- "debounced bytes" --> P
```

* **Next.js** owns metadata (users, workspaces, page tree, roles, comments, versions) through REST + Prisma.
* **WebSocket servers** own *live* documents. One `Y.Doc` + `Awareness` per active page ("room") per server.
* **Redis** carries Yjs updates and awareness between servers, and a small control channel from the REST API to the servers.
* **PostgreSQL** stores `Page.ydocState` (`Y.encodeStateAsUpdate`) and `PageVersion.state` snapshots as `Bytes`.

## Yjs CRDT flow

```mermaid
sequenceDiagram
  participant C as Client (Y.Doc)
  participant S as WS server (room Y.Doc)
  participant DB as PostgreSQL
  C->>S: WebSocket upgrade (cookie JWT, Origin check)
  S->>DB: role = resolve(workspace role, page permission)
  S->>DB: load Page.ydocState (first user only)
  S-->>C: AUTH {role}
  S-->>C: SyncStep1 (state vector)
  C->>S: SyncStep2 (what server lacks, incl. offline edits)
  C->>S: SyncStep1
  S-->>C: SyncStep2 (what client lacks)
  loop every edit
    C->>S: Update (only if role = EDIT, else dropped + DENIED)
    S-->>C: Update to the other local clients
    S->>DB: save (throttled to every 2 s, immediate on last disconnect)
  end
```

Why this converges: every Yjs operation has a globally unique `(clientID, clock)` id, and integration is commutative, associative and idempotent. Two clients that edit offline and then exchange the updates each is missing reach the same state in any order. The tests assert byte-identical state vectors.

**Offline:** the browser `Y.Doc` keeps accepting edits while the socket is down. On reconnect the provider runs the normal sync handshake. No special merge code exists.

**Comments:** anchors are `Y.RelativePosition`s stored in PostgreSQL, so highlights follow the text as others type. They are rendered as ProseMirror decorations; the document is not modified, which is why read-only `COMMENT` users can comment.

**Restore:** a snapshot is restored as a *new transaction* (delete current content, insert a clone of the snapshot's content). History is kept, nothing rewinds, and the change replicates like any other edit.

## Redis Pub/Sub scaling

```mermaid
sequenceDiagram
  participant A as Client A
  participant S1 as ws-server-1
  participant R as Redis doc:PAGE
  participant S2 as ws-server-2
  participant B as Client B
  A->>S1: Update
  S1->>R: PUBLISH {instance=1, UPDATE, bytes}
  R-->>S1: echo (ignored: own instance id)
  R-->>S2: message
  S2->>S2: Y.applyUpdate(doc, bytes, origin="redis")
  S2-->>B: Update
  Note over S2: origin="redis" updates are NOT re-published (no loops)
```

Bus message kinds (`shared/protocol.ts`): `UPDATE`, `AWARENESS`, `AWARENESS_QUERY`, `SYNC_REQUEST`.

* **Room start:** after loading from PostgreSQL a server subscribes to `doc:${pageId}` and publishes `SYNC_REQUEST` (its state vector) and `AWARENESS_QUERY`. Peers answer with the missing diff and their presence, so a late joiner never loses edits that were not yet persisted (tested).
* **Presence:** awareness updates are relayed; when a client disconnects its server publishes the removal, so avatars disappear on other servers.
* **Persistence:** every server hosting a room saves the full merged state, so any one of them can fail without data loss beyond ≤2 s.
* **Control channel `ctl`:** the REST API cannot touch in-memory documents, so it publishes `flush`, `restore` and `refresh-perms`. Servers hosting the room act; for `restore` a Redis `SET NX` lock picks exactly one applier and the result spreads via the normal doc channel. `rooms:${pageId}` (a Redis set) tells the API whether anyone is editing; if not, it edits the stored bytes directly.

## RBAC

Effective role = workspace owner / page creator (`EDIT` + manage) → explicit `PagePermission` → workspace default → none. Guests have a membership with `role = null` and see only shared pages.

* REST: `requirePage(user, page, min)` on every route.
* WebSocket: on upgrade (no access ⇒ 403/404) and on **every message** via `authorizeClientMessage`: sync step 2 and update frames from `VIEW`/`COMMENT` are dropped and answered with `DENIED`. Awareness is still allowed.
* Live changes: the Share modal publishes `refresh-perms`; open sockets get a new `AUTH` role, or are closed with 4403 if access was removed.
