# 10-minute presentation: Real-time Collaborative Workspace

Timing: 10 slides, about 1 minute each. Live demo is folded into slides 4 and 7.

## Slide 1: Title and the one-sentence pitch (0:45)
**"Notion-style pages that several people edit at once, that still work offline, and that scale across servers."**
Say: what you will see: one page open in two tabs on two *different* servers, in sync.

## Slide 2: The problem (1:00)
- Naïve approach: last-write-wins on whole documents → people overwrite each other.
- Operational Transform needs a central server to order every edit → hard to scale, hard to do offline.
- Requirements: concurrent edits, offline edits, presence, permissions, history, and horizontal scale.

## Slide 3: Design in one picture (1:15)
Show the component diagram from `ARCHITECTURE.md`.
- Next.js + PostgreSQL for metadata, roles, comments, versions.
- Custom Node WebSocket servers hold live `Y.Doc`s; Redis Pub/Sub links them.
- Document state stored as Yjs bytes in PostgreSQL.

## Slide 4: Why a CRDT (Yjs) (1:15)
- Every operation has a unique `(clientID, clock)`; merging is commutative, associative, idempotent.
- No central ordering: the server is just another peer.
- **Demo:** *Go offline* in both tabs, type in the same paragraph, *Reconnect*: both edits survive.

## Slide 5: Scaling with Redis (1:15)
Show the sequence diagram.
- Each server publishes its local updates to `doc:<pageId>`; peers apply them with origin `redis` (never re-published).
- A new room asks peers for a diff (`SYNC_REQUEST`) so unsaved edits are not lost.
- Presence crosses servers; disconnects are broadcast.

## Slide 6: Persistence and history (0:45)
- Throttled save every 2 s, immediate flush on last disconnect, rehydrate on first join.
- Automatic snapshots on room close; manual snapshots from the UI.
- Restore = a new CRDT transaction, so it replicates live and is itself undoable ("Before restore" snapshot).

## Slide 7: Permissions and comments (1:15)
- Roles VIEW / COMMENT / EDIT enforced in REST **and** per WebSocket frame.
- **Demo:** promote Carol in the Share modal: her editor unlocks instantly, with no reload. Show a tampered client being rejected (`rejected` counter in `/health`).
- Comments anchor with Yjs relative positions, so highlights follow the text.

## Slide 8: Challenges (1:00)
1. Mutable state across processes: the REST API cannot reach live docs → a Redis control channel with ack + `SET NX` lock so exactly one server applies a restore.
2. Echo loops between servers → instance ids and update origins.
3. Comments from read-only users → anchors live in the DB, not the document.
4. Early messages lost during room rehydration → queue until the room is ready.
5. Version skew in the TipTap packages → pin one release line.

## Slide 9: Benchmark results (1:00)
Command: `npm run load` (50 clients across ports 4001/4002, ~2 edits/s each, shared document).

Reference run, **in-process harness** (`--harness`; real room code, in-memory store and bus; all 50 clients and both servers share one Node process in a sandbox, so it is CPU-bound and pessimistic):

| Run | Edits | p50 | p95 | p99 | Convergence |
|---|---|---|---|---|---|
| 10 s | 981 | 22 ms | 111 ms | 147 ms | pass (981/981) |
| 20 s | 1,695 | 147 ms | 672 ms | 752 ms | pass (1,695/1,695) |

Throughput ≈ 80-90 edits/s accepted and ≈ 4,000 deliveries/s. Latency rises as the single test document grows (hundreds of appended paragraphs) and the process saturates a core.
**Replace this table with your own `npm run load` output** (real Redis, PostgreSQL, separate processes) before presenting; the script writes `tests/load-test-results.json`.

## Slide 10: Next steps (0:45)
- Real-time comments and mentions over the same channel; notifications.
- Block-level permissions, public share links, workspace member management UI.
- IndexedDB persistence for offline reloads; compaction of long Yjs histories.
- Redis Streams for guaranteed delivery; sharding rooms by consistent hash; rate limiting.
- E2E browser tests (Playwright) with two simulated users.

## Q&A prompts
- *What if Redis is down?* Servers keep working for their own clients; cross-server sync resumes and heals through `SYNC_REQUEST` when it returns.
- *Does the doc grow forever?* Yes, tombstones; mitigate with snapshot-based compaction.
