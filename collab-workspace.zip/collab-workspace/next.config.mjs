/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false,
  experimental: {
    // allow importing the framework-agnostic code in /shared from the app
    externalDir: true,
  },
};

export default nextConfig;
