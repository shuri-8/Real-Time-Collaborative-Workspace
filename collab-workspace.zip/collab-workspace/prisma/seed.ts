import "dotenv/config";
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { encodeState, makeDocFromBlocks } from "../shared/yjs-utils";

const prisma = new PrismaClient();
const PASSWORD = "password123";

// Stable ids so the README, the load test and your bookmarks always point at the same rows.
export const IDS = {
  alice: "user-alice",
  bob: "user-bob",
  carol: "user-carol",
  dave: "user-dave",
  workspace: "demo-workspace",
  welcome: "demo-page-welcome",
  gettingStarted: "demo-page-getting-started",
  roadmap: "demo-page-roadmap",
  loadtest: "demo-page-loadtest",
};

async function main() {
  const hash = await bcrypt.hash(PASSWORD, 10);
  const users = [
    { id: IDS.alice, email: "alice@example.com", name: "Alice Nguyen", color: "#d9480f" },
    { id: IDS.bob, email: "bob@example.com", name: "Bob Martins", color: "#0b7285" },
    { id: IDS.carol, email: "carol@example.com", name: "Carol Singh", color: "#5f3dc4" },
    { id: IDS.dave, email: "dave@example.com", name: "Dave Okafor", color: "#2b8a3e" },
  ];
  for (const u of users) {
    await prisma.user.upsert({ where: { id: u.id }, update: {}, create: { ...u, passwordHash: hash } });
  }

  await prisma.workspace.upsert({
    where: { id: IDS.workspace },
    update: {},
    create: { id: IDS.workspace, name: "Demo workspace", ownerId: IDS.alice },
  });
  const members: Array<[string, "VIEW" | "COMMENT" | "EDIT" | null]> = [
    [IDS.alice, "EDIT"],
    [IDS.bob, "EDIT"], // can edit every page
    [IDS.carol, "VIEW"], // read-only everywhere
    [IDS.dave, null], // guest: only sees pages shared with him
  ];
  for (const [userId, role] of members) {
    await prisma.workspaceMember.upsert({
      where: { workspaceId_userId: { workspaceId: IDS.workspace, userId } },
      update: { role },
      create: { workspaceId: IDS.workspace, userId, role },
    });
  }

  const welcome = makeDocFromBlocks([
    { type: "heading", level: 1, text: "Welcome to the demo workspace" },
    { type: "paragraph", text: "Open this page in two browser windows (try ?ws=1 and ?ws=2) and type in both. Each window talks to a different WebSocket server; Redis keeps them in sync." },
    { type: "heading", level: 2, text: "Things to try" },
    { type: "bulletList", items: ["Watch the coloured cursors and the avatar stack", "Click \"Go offline\", edit, then reconnect", "Select text and add a comment", "Save a version, change the text, then restore it"] },
  ]);
  const gettingStarted = makeDocFromBlocks([
    { type: "heading", level: 1, text: "Getting started" },
    { type: "paragraph", text: "Alice owns this workspace. Bob can edit, Carol can only read, and Dave is a guest who sees only the pages shared with him." },
  ]);
  const roadmap = makeDocFromBlocks([
    { type: "heading", level: 1, text: "Roadmap" },
    { type: "bulletList", items: ["Ship real-time comments", "Page templates", "Export to Markdown"] },
  ]);

  const pages = [
    { id: IDS.welcome, title: "Welcome", parentId: null, position: 0, doc: welcome },
    { id: IDS.gettingStarted, title: "Getting started", parentId: IDS.welcome, position: 0, doc: gettingStarted },
    { id: IDS.roadmap, title: "Roadmap", parentId: IDS.welcome, position: 1, doc: roadmap },
    { id: IDS.loadtest, title: "Load-test sandbox", parentId: null, position: 1, doc: makeDocFromBlocks([{ type: "heading", level: 1, text: "Load-test sandbox" }]) },
  ];
  for (const p of pages) {
    await prisma.page.upsert({
      where: { id: p.id },
      update: {},
      create: {
        id: p.id,
        workspaceId: IDS.workspace,
        parentId: p.parentId,
        title: p.title,
        position: p.position,
        createdById: IDS.alice,
        ydocState: Buffer.from(encodeState(p.doc)),
      },
    });
  }

  // Dave (guest) may comment on the Welcome page only.
  await prisma.pagePermission.upsert({
    where: { pageId_userId: { pageId: IDS.welcome, userId: IDS.dave } },
    update: { role: "COMMENT" },
    create: { pageId: IDS.welcome, userId: IDS.dave, role: "COMMENT" },
  });

  if ((await prisma.comment.count({ where: { pageId: IDS.welcome } })) === 0) {
    await prisma.comment.create({
      data: { pageId: IDS.welcome, authorId: IDS.bob, body: "Select any text on the page to anchor a new comment to it.", quote: "" },
    });
  }

  console.log("Seeded. Sign in with any of these (password: %s):", PASSWORD);
  for (const u of users) console.log("  %s", u.email);
  console.log("Demo page: /workspace/%s/%s", IDS.workspace, IDS.welcome);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
