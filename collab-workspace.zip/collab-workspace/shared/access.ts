import type { PrismaClient } from "@prisma/client";
import { Access, Role, resolveRole } from "./rbac";

/** Effective access of one user on one page (workspace role + explicit page permission). */
export async function getPageAccess(
  prisma: PrismaClient,
  userId: string,
  pageId: string
): Promise<(Access & { workspaceId: string }) | null> {
  const page = await prisma.page.findUnique({
    where: { id: pageId },
    select: {
      workspaceId: true,
      createdById: true,
      workspace: { select: { ownerId: true } },
      permissions: { where: { userId }, select: { role: true } },
    },
  });
  if (!page) return null;
  const member = await prisma.workspaceMember.findUnique({
    where: { workspaceId_userId: { workspaceId: page.workspaceId, userId } },
    select: { role: true },
  });
  const access = resolveRole({
    isWorkspaceOwner: page.workspace.ownerId === userId,
    isPageCreator: page.createdById === userId,
    membershipRole: member ? ((member.role as Role | null) ?? null) : undefined,
    pageRole: (page.permissions[0]?.role as Role | undefined) ?? null,
  });
  return { ...access, workspaceId: page.workspaceId };
}
