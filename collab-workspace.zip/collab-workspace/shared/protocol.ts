import * as encoding from "lib0/encoding";
import * as decoding from "lib0/decoding";
import { Role, canEdit } from "./rbac";

/** Top-level message types on the client <-> server WebSocket (binary). */
export const MSG = {
  SYNC: 0, // y-protocols/sync
  AWARENESS: 1, // y-protocols/awareness
  AUTH: 2, // server -> client: { role }
  DENIED: 3, // server -> client: reason string (a rejected mutation)
} as const;

/** Sub-types of MSG.SYNC (y-protocols/sync). */
export const SYNC = { STEP1: 0, STEP2: 1, UPDATE: 2 } as const;

/** Message kinds on the Redis Pub/Sub channel `doc:${pageId}`. */
export const BUS = {
  UPDATE: 0, // Yjs update
  AWARENESS: 1, // awareness update
  AWARENESS_QUERY: 2, // "please re-publish your awareness states"
  SYNC_REQUEST: 3, // payload = state vector; peers answer with a diff UPDATE
} as const;

export interface MessageInfo {
  type: number;
  syncType?: number;
}

export function inspectMessage(data: Uint8Array): MessageInfo | null {
  try {
    const d = decoding.createDecoder(data);
    const type = decoding.readVarUint(d);
    if (type === MSG.SYNC) return { type, syncType: decoding.readVarUint(d) };
    return { type };
  } catch {
    return null;
  }
}

/** Does this client message change the document? */
export function isDocMutation(info: MessageInfo): boolean {
  return info.type === MSG.SYNC && (info.syncType === SYNC.STEP2 || info.syncType === SYNC.UPDATE);
}

export type Authorization = { ok: true } | { ok: false; reason: string };

/**
 * RBAC gate for every binary message received from a client.
 *  - malformed messages are rejected
 *  - VIEW / COMMENT users may read (sync step 1) and publish awareness, but never mutate the doc
 */
export function authorizeClientMessage(role: Role | null, data: Uint8Array): Authorization {
  const info = inspectMessage(data);
  if (!info) return { ok: false, reason: "malformed message" };
  if (info.type === MSG.SYNC) {
    if (isDocMutation(info) && !canEdit(role)) {
      return { ok: false, reason: `role ${role ?? "NONE"} cannot modify the document` };
    }
    return { ok: true };
  }
  if (info.type === MSG.AWARENESS) return role ? { ok: true } : { ok: false, reason: "no access" };
  return { ok: false, reason: "unsupported message type" };
}

export function encodeAuth(role: Role): Uint8Array {
  const e = encoding.createEncoder();
  encoding.writeVarUint(e, MSG.AUTH);
  encoding.writeVarString(e, JSON.stringify({ role }));
  return encoding.toUint8Array(e);
}

export function encodeDenied(reason: string): Uint8Array {
  const e = encoding.createEncoder();
  encoding.writeVarUint(e, MSG.DENIED);
  encoding.writeVarString(e, reason);
  return encoding.toUint8Array(e);
}

export function encodeBus(instanceId: string, kind: number, payload: Uint8Array): Uint8Array {
  const e = encoding.createEncoder();
  encoding.writeVarString(e, instanceId);
  encoding.writeVarUint(e, kind);
  encoding.writeVarUint8Array(e, payload);
  return encoding.toUint8Array(e);
}

export function decodeBus(data: Uint8Array): { instanceId: string; kind: number; payload: Uint8Array } {
  const d = decoding.createDecoder(data);
  return {
    instanceId: decoding.readVarString(d),
    kind: decoding.readVarUint(d),
    payload: decoding.readVarUint8Array(d),
  };
}

export const docChannel = (pageId: string) => `doc:${pageId}`;
export const CTL_CHANNEL = "ctl";
