// Pure, dependency-free RBAC rules shared by the REST API, the WebSocket server and the tests.

export type Role = "VIEW" | "COMMENT" | "EDIT";

const RANK: Record<Role, number> = { VIEW: 0, COMMENT: 1, EDIT: 2 };

export function hasRole(role: Role | null | undefined, min: Role): boolean {
  return !!role && RANK[role] >= RANK[min];
}
export const canRead = (r: Role | null | undefined) => hasRole(r, "VIEW");
export const canComment = (r: Role | null | undefined) => hasRole(r, "COMMENT");
export const canEdit = (r: Role | null | undefined) => hasRole(r, "EDIT");

export interface AccessInput {
  isWorkspaceOwner: boolean;
  isPageCreator: boolean;
  /** Default role of the workspace membership. null = guest, undefined = not a member. */
  membershipRole?: Role | null;
  /** Explicit role granted on this page (overrides the workspace default, up or down). */
  pageRole?: Role | null;
}

export interface Access {
  role: Role | null;
  /** May share the page / delete it. */
  canManage: boolean;
}

export function resolveRole(i: AccessInput): Access {
  if (i.isWorkspaceOwner) return { role: "EDIT", canManage: true };
  if (i.isPageCreator) return { role: "EDIT", canManage: true };
  const role = i.pageRole ?? i.membershipRole ?? null;
  return { role, canManage: false };
}
