import * as Y from "yjs";

/** TipTap's Collaboration extension stores the document in this XmlFragment. */
export const FRAGMENT = "default";

export type Block =
  | { type: "paragraph"; text: string }
  | { type: "heading"; level: 1 | 2 | 3; text: string }
  | { type: "bulletList"; items: string[] };

function para(text: string): Y.XmlElement {
  const p = new Y.XmlElement("paragraph");
  const t = new Y.XmlText();
  if (text) t.insert(0, text);
  p.insert(0, [t]);
  return p;
}

/** Build a ProseMirror-compatible Yjs document (used by the seed script and tests). */
export function makeDocFromBlocks(blocks: Block[]): Y.Doc {
  const doc = new Y.Doc();
  const frag = doc.getXmlFragment(FRAGMENT);
  const nodes: Y.XmlElement[] = blocks.map((b) => {
    if (b.type === "paragraph") return para(b.text);
    if (b.type === "heading") {
      const h = new Y.XmlElement("heading");
      h.setAttribute("level", String(b.level) as any);
      const t = new Y.XmlText();
      t.insert(0, b.text);
      h.insert(0, [t]);
      return h;
    }
    const ul = new Y.XmlElement("bulletList");
    ul.insert(
      0,
      b.items.map((item) => {
        const li = new Y.XmlElement("listItem");
        li.insert(0, [para(item)]);
        return li;
      })
    );
    return ul;
  });
  frag.insert(0, nodes);
  return doc;
}

export function encodeState(doc: Y.Doc): Uint8Array {
  return Y.encodeStateAsUpdate(doc);
}

export function docFromState(state: Uint8Array | null | undefined): Y.Doc {
  const doc = new Y.Doc();
  if (state && state.length) Y.applyUpdate(doc, state);
  return doc;
}

/**
 * Restore a snapshot *as a new CRDT transaction* on top of the live document.
 * History is preserved (nothing is rewound), the change replicates like any other edit,
 * and every connected client / server instance converges on the restored content.
 */
export function restoreSnapshot(doc: Y.Doc, snapshotState: Uint8Array, origin: unknown = "restore"): void {
  const snap = docFromState(snapshotState);
  const src = snap.getXmlFragment(FRAGMENT);
  const dst = doc.getXmlFragment(FRAGMENT);
  doc.transact(() => {
    if (dst.length > 0) dst.delete(0, dst.length);
    const clones = src.toArray().map((n) => n.clone()) as Array<Y.XmlElement | Y.XmlText>;
    if (clones.length) dst.insert(0, clones);
  }, origin);
  snap.destroy();
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function textToHtml(t: Y.XmlText): string {
  return (t.toDelta() as Array<{ insert: unknown; attributes?: Record<string, unknown> }>)
    .map((op) => {
      if (typeof op.insert !== "string") return "";
      let s = esc(op.insert);
      const a = op.attributes ?? {};
      if (a.code) s = `<code>${s}</code>`;
      if (a.bold) s = `<strong>${s}</strong>`;
      if (a.italic) s = `<em>${s}</em>`;
      if (a.strike) s = `<s>${s}</s>`;
      return s;
    })
    .join("");
}

function nodeToHtml(n: Y.XmlElement | Y.XmlText | Y.XmlHook): string {
  if (n instanceof Y.XmlText) return textToHtml(n);
  if (!(n instanceof Y.XmlElement)) return "";
  const inner = n.toArray().map(nodeToHtml).join("");
  switch (n.nodeName) {
    case "paragraph":
      return `<p>${inner}</p>`;
    case "heading": {
      const lvl = Math.min(3, Math.max(1, Number(n.getAttribute("level") ?? 1)));
      return `<h${lvl}>${inner}</h${lvl}>`;
    }
    case "bulletList":
      return `<ul>${inner}</ul>`;
    case "orderedList":
      return `<ol>${inner}</ol>`;
    case "listItem":
      return `<li>${inner}</li>`;
    case "blockquote":
      return `<blockquote>${inner}</blockquote>`;
    case "codeBlock":
      return `<pre><code>${inner}</code></pre>`;
    case "hardBreak":
      return "<br/>";
    case "horizontalRule":
      return "<hr/>";
    default:
      return inner;
  }
}

/** Safe (escaped) HTML rendering of a snapshot, used by the version-history preview. */
export function stateToHtml(state: Uint8Array): string {
  const doc = docFromState(state);
  const html = doc
    .getXmlFragment(FRAGMENT)
    .toArray()
    .map(nodeToHtml)
    .join("");
  doc.destroy();
  return html || "<p><em>(empty document)</em></p>";
}

function nodeToText(n: Y.XmlElement | Y.XmlText | Y.XmlHook): string {
  if (n instanceof Y.XmlText) return n.toString().replace(/<[^>]+>/g, "");
  if (n instanceof Y.XmlElement) return n.toArray().map(nodeToText).join("");
  return "";
}

/** Plain text, one line per top-level block. Handy for convergence checks. */
export function fragmentToPlainText(doc: Y.Doc): string {
  return doc
    .getXmlFragment(FRAGMENT)
    .toArray()
    .map(nodeToText)
    .join("\n");
}
