import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { TOKEN_TTL_SECONDS, signToken } from "@shared/auth-token";
import { HttpError, body, route, setAuthCookie } from "@/lib/api";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

const schema = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1) });

export const POST = route(async (req) => {
  const data = await body(req, schema);
  const user = await prisma.user.findUnique({ where: { email: data.email } });
  const ok = user ? await bcrypt.compare(data.password, user.passwordHash) : false;
  if (!user || !ok) throw new HttpError(401, "Email or password is incorrect.");
  const token = await signToken({ sub: user.id, name: user.name });
  const res = NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, color: user.color } });
  setAuthCookie(res, token, TOKEN_TTL_SECONDS);
  return res;
});
