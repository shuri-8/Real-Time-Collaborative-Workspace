import { NextResponse } from "next/server";
import { route, setAuthCookie } from "@/lib/api";

export const dynamic = "force-dynamic";

export const POST = route(async () => {
  const res = NextResponse.json({ ok: true });
  setAuthCookie(res, "", 0);
  return res;
});
