import { HttpError, requireUser, route } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const user = await requireUser().catch(() => {
    throw new HttpError(401, "Not signed in.");
  });
  return { user };
});
