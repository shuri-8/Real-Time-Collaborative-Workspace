import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { TOKEN_TTL_SECONDS, signToken } from "@shared/auth-token";
import { encodeState, makeDocFromBlocks } from "@shared/yjs-utils";
import { HttpError, body, randomColor, route, setAuthCookie } from "@/lib/api";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

const schema = z.object({
  name: z.string().trim().min(1, "Enter your name").max(60),
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  password: z.string().min(8, "Use at least 8 characters").max(200),
});

export const POST = route(async (req) => {
  const data = await body(req, schema);
  if (await prisma.user.findUnique({ where: { email: data.email } })) {
    throw new HttpError(409, "An account with this email already exists.");
  }
  const user = await prisma.user.create({
    data: {
      name: data.name,
      email: data.email,
      passwordHash: await bcrypt.hash(data.password, 10),
      color: randomColor(),
    },
  });
  const ws = await prisma.workspace.create({
    data: { name: `${data.name}'s workspace`, ownerId: user.id, members: { create: { userId: user.id, role: "EDIT" } } },
  });
  const welcome = makeDocFromBlocks([
    { type: "heading", level: 1, text: "Getting started" },
    { type: "paragraph", text: "Everything on this page is edited in real time. Share it from the top bar and watch cursors appear." },
    { type: "bulletList", items: ["Create nested pages from the sidebar", "Select text to leave a comment", "Save a version before a big rewrite"] },
  ]);
  await prisma.page.create({
    data: { workspaceId: ws.id, title: "Getting started", createdById: user.id, ydocState: Buffer.from(encodeState(welcome)) },
  });

  const token = await signToken({ sub: user.id, name: user.name });
  const res = NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, color: user.color }, workspaceId: ws.id });
  setAuthCookie(res, token, TOKEN_TTL_SECONDS);
  return res;
});
