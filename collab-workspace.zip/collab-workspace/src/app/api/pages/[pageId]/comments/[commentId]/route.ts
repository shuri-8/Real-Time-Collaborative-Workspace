import { z } from "zod";
import { HttpError, body, requirePage, requireUser, route } from "@/lib/api";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

async function load(pageId: string, commentId: string) {
  const c = await prisma.comment.findUnique({ where: { id: commentId }, select: { id: true, pageId: true, authorId: true } });
  if (!c || c.pageId !== pageId) throw new HttpError(404, "Comment not found.");
  return c;
}

export const PATCH = route(async (req, { params }) => {
  const user = await requireUser();
  const access = await requirePage(user.id, params.pageId, "COMMENT");
  const c = await load(params.pageId, params.commentId);
  const data = await body(req, z.object({ body: z.string().trim().min(1).max(2000).optional(), resolved: z.boolean().optional() }));
  if (data.body !== undefined && c.authorId !== user.id) throw new HttpError(403, "Only the author can edit a comment.");
  if (data.resolved !== undefined && c.authorId !== user.id && access.role !== "EDIT") {
    throw new HttpError(403, "Only the author or an editor can resolve a comment.");
  }
  await prisma.comment.update({ where: { id: c.id }, data });
  return { ok: true };
});

export const DELETE = route(async (_req, { params }) => {
  const user = await requireUser();
  const access = await requirePage(user.id, params.pageId, "COMMENT");
  const c = await load(params.pageId, params.commentId);
  if (c.authorId !== user.id && !access.canManage) throw new HttpError(403, "Only the author or the page owner can delete a comment.");
  await prisma.comment.delete({ where: { id: c.id } });
  return { ok: true };
});
