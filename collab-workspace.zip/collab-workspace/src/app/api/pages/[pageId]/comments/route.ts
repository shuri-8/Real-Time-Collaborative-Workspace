import { z } from "zod";
import { HttpError, body, requirePage, requireUser, route } from "@/lib/api";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export const GET = route(async (_req, { params }) => {
  const user = await requireUser();
  await requirePage(user.id, params.pageId, "VIEW");
  const comments = await prisma.comment.findMany({
    where: { pageId: params.pageId },
    orderBy: { createdAt: "asc" },
    select: {
      id: true, parentId: true, body: true, quote: true, anchorFrom: true, anchorTo: true, resolved: true, createdAt: true,
      author: { select: { id: true, name: true, color: true } },
    },
  });
  return { comments };
});

const anchor = z.object({}).passthrough();

export const POST = route(async (req, { params }) => {
  const user = await requireUser();
  await requirePage(user.id, params.pageId, "COMMENT");
  const data = await body(
    req,
    z.object({
      body: z.string().trim().min(1, "Write something first").max(2000),
      quote: z.string().max(500).default(""),
      anchorFrom: anchor.optional(),
      anchorTo: anchor.optional(),
      parentId: z.string().optional(),
    })
  );
  if (data.parentId) {
    const parent = await prisma.comment.findUnique({ where: { id: data.parentId }, select: { pageId: true, parentId: true } });
    if (!parent || parent.pageId !== params.pageId || parent.parentId) throw new HttpError(400, "You can only reply to a top-level comment on this page.");
  }
  const comment = await prisma.comment.create({
    data: {
      pageId: params.pageId,
      authorId: user.id,
      body: data.body,
      quote: data.parentId ? "" : data.quote,
      parentId: data.parentId ?? null,
      anchorFrom: data.parentId ? undefined : (data.anchorFrom as object | undefined),
      anchorTo: data.parentId ? undefined : (data.anchorTo as object | undefined),
    },
    select: { id: true },
  });
  return { comment };
});
