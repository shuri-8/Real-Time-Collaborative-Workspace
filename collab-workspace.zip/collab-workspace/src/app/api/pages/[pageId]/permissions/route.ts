import { z } from "zod";
import { Role } from "@shared/rbac";
import { HttpError, body, requirePage, requireUser, route } from "@/lib/api";
import { notifyPermissionsChanged } from "@/lib/ctl";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

const userSel = { id: true, name: true, email: true, color: true } as const;

export const GET = route(async (_req, { params }) => {
  const user = await requireUser();
  const access = await requirePage(user.id, params.pageId, "VIEW");
  const page = await prisma.page.findUniqueOrThrow({
    where: { id: params.pageId },
    select: {
      workspaceId: true,
      createdBy: { select: userSel },
      workspace: { select: { owner: { select: userSel } } },
      permissions: { select: { role: true, user: { select: userSel } } },
    },
  });
  const members = await prisma.workspaceMember.findMany({
    where: { workspaceId: page.workspaceId, role: { not: null } },
    select: { role: true, user: { select: userSel } },
  });
  type Person = { userId: string; name: string; email: string; color: string; role: Role; source: "owner" | "creator" | "page" | "workspace" };
  const people = new Map<string, Person>();
  const add = (u: { id: string; name: string; email: string; color: string }, role: Role, source: Person["source"]) =>
    people.set(u.id, { userId: u.id, name: u.name, email: u.email, color: u.color, role, source });
  for (const m of members) add(m.user, m.role as Role, "workspace");
  for (const p of page.permissions) add(p.user, p.role as Role, "page");
  add(page.createdBy, "EDIT", "creator");
  add(page.workspace.owner, "EDIT", "owner");
  return { canManage: access.canManage, people: [...people.values()] };
});

/** Invite a user (by email) or change their role on this page. */
export const PUT = route(async (req, { params }) => {
  const user = await requireUser();
  const access = await requirePage(user.id, params.pageId, "VIEW");
  if (!access.canManage) throw new HttpError(403, "Only the page creator or workspace owner can share this page.");
  const data = await body(req, z.object({ email: z.string().trim().toLowerCase().email(), role: z.enum(["VIEW", "COMMENT", "EDIT"]) }));
  const target = await prisma.user.findUnique({ where: { email: data.email }, select: userSel });
  if (!target) throw new HttpError(404, "No account uses that email address. Ask them to register first.");
  const page = await prisma.page.findUniqueOrThrow({ where: { id: params.pageId }, select: { workspaceId: true, createdById: true, workspace: { select: { ownerId: true } } } });
  if (target.id === page.workspace.ownerId || target.id === page.createdById) {
    throw new HttpError(400, "That person already owns this page.");
  }
  await prisma.$transaction([
    prisma.pagePermission.upsert({
      where: { pageId_userId: { pageId: params.pageId, userId: target.id } },
      create: { pageId: params.pageId, userId: target.id, role: data.role },
      update: { role: data.role },
    }),
    // guests can open only the pages shared with them (membership role = null)
    prisma.workspaceMember.upsert({
      where: { workspaceId_userId: { workspaceId: page.workspaceId, userId: target.id } },
      create: { workspaceId: page.workspaceId, userId: target.id, role: null },
      update: {},
    }),
  ]);
  await notifyPermissionsChanged(params.pageId);
  return { person: { userId: target.id, name: target.name, email: target.email, color: target.color, role: data.role, source: "page" } };
});

export const DELETE = route(async (req, { params }) => {
  const user = await requireUser();
  const access = await requirePage(user.id, params.pageId, "VIEW");
  if (!access.canManage) throw new HttpError(403, "Only the page creator or workspace owner can change sharing.");
  const userId = new URL(req.url).searchParams.get("userId");
  if (!userId) throw new HttpError(400, "userId is required.");
  await prisma.pagePermission.deleteMany({ where: { pageId: params.pageId, userId } });
  await notifyPermissionsChanged(params.pageId);
  return { ok: true };
});
