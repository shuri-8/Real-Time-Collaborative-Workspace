import { z } from "zod";
import { HttpError, body, requirePage, requireUser, route } from "@/lib/api";
import { notifyPermissionsChanged } from "@/lib/ctl";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export const GET = route(async (_req, { params }) => {
  const user = await requireUser();
  const access = await requirePage(user.id, params.pageId, "VIEW");
  const page = await prisma.page.findUnique({
    where: { id: params.pageId },
    select: { id: true, title: true, icon: true, parentId: true, workspaceId: true, updatedAt: true },
  });
  return { page, role: access.role, canManage: access.canManage };
});

export const PATCH = route(async (req, { params }) => {
  const user = await requireUser();
  await requirePage(user.id, params.pageId, "EDIT");
  const data = await body(
    req,
    z.object({
      title: z.string().trim().max(200).optional(),
      icon: z.string().max(8).nullable().optional(),
      parentId: z.string().nullable().optional(),
      position: z.number().int().min(0).optional(),
    })
  );
  if (data.parentId !== undefined && data.parentId !== null) {
    // refuse to move a page below itself
    let cursor: string | null = data.parentId;
    while (cursor) {
      if (cursor === params.pageId) throw new HttpError(400, "A page cannot be moved inside itself.");
      const p: { parentId: string | null } | null = await prisma.page.findUnique({ where: { id: cursor }, select: { parentId: true } });
      cursor = p?.parentId ?? null;
    }
  }
  const page = await prisma.page.update({
    where: { id: params.pageId },
    data: { ...data, title: data.title === "" ? "Untitled" : data.title },
    select: { id: true, title: true, icon: true, parentId: true, position: true },
  });
  return { page };
});

export const DELETE = route(async (_req, { params }) => {
  const user = await requireUser();
  const access = await requirePage(user.id, params.pageId, "EDIT");
  if (!access.canManage) throw new HttpError(403, "Only the page creator or workspace owner can delete a page.");
  await prisma.page.delete({ where: { id: params.pageId } });
  await notifyPermissionsChanged(params.pageId); // live connections close: the page no longer exists
  return { ok: true };
});
