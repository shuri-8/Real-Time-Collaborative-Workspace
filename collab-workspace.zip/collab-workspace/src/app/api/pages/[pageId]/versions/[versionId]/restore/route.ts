import { docFromState, encodeState, restoreSnapshot } from "@shared/yjs-utils";
import { HttpError, requirePage, requireUser, route } from "@/lib/api";
import { ctlRequest } from "@/lib/ctl";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export const POST = route(async (_req, { params }) => {
  const user = await requireUser();
  await requirePage(user.id, params.pageId, "EDIT");
  const version = await prisma.pageVersion.findUnique({ where: { id: params.versionId } });
  if (!version || version.pageId !== params.pageId) throw new HttpError(404, "Version not found.");

  // 1. persist the live state and keep it as a safety net so a restore can itself be undone
  await ctlRequest({ type: "flush", pageId: params.pageId });
  const page = await prisma.page.findUniqueOrThrow({ where: { id: params.pageId }, select: { ydocState: true } });
  if (page.ydocState) {
    await prisma.pageVersion.create({
      data: { pageId: params.pageId, state: page.ydocState, kind: "AUTO", label: "Before restore", createdById: user.id },
    });
  }

  // 2. apply the restore to the LIVE document (it replicates to every client and server instance)...
  const outcome = await ctlRequest({ type: "restore", pageId: params.pageId, versionId: params.versionId });
  if (outcome === "acked") return { ok: true, live: true };
  if (outcome === "timeout") throw new HttpError(504, "The live editing server did not respond. Try again in a moment.");

  // 3. ...or, when nobody is editing, straight onto the stored document.
  const doc = docFromState(page.ydocState ? new Uint8Array(page.ydocState) : null);
  restoreSnapshot(doc, new Uint8Array(version.state));
  await prisma.page.update({ where: { id: params.pageId }, data: { ydocState: Buffer.from(encodeState(doc)) } });
  return { ok: true, live: false };
});
