import { stateToHtml } from "@shared/yjs-utils";
import { HttpError, requirePage, requireUser, route } from "@/lib/api";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

/** Read-only preview of a snapshot (HTML is generated server-side with escaped text). */
export const GET = route(async (_req, { params }) => {
  const user = await requireUser();
  await requirePage(user.id, params.pageId, "VIEW");
  const v = await prisma.pageVersion.findUnique({ where: { id: params.versionId } });
  if (!v || v.pageId !== params.pageId) throw new HttpError(404, "Version not found.");
  return { id: v.id, label: v.label, kind: v.kind, createdAt: v.createdAt, html: stateToHtml(new Uint8Array(v.state)) };
});
