import { z } from "zod";
import { encodeState, docFromState } from "@shared/yjs-utils";
import { body, requirePage, requireUser, route } from "@/lib/api";
import { ctlRequest } from "@/lib/ctl";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export const GET = route(async (_req, { params }) => {
  const user = await requireUser();
  await requirePage(user.id, params.pageId, "VIEW");
  const versions = await prisma.pageVersion.findMany({
    where: { pageId: params.pageId },
    orderBy: { createdAt: "desc" },
    take: 100,
    select: { id: true, label: true, kind: true, createdAt: true, createdBy: { select: { id: true, name: true } } },
  });
  return { versions };
});

/** Manual snapshot of the current document. */
export const POST = route(async (req, { params }) => {
  const user = await requireUser();
  await requirePage(user.id, params.pageId, "EDIT");
  const { label } = await body(req, z.object({ label: z.string().trim().max(120).optional() }));
  // ask the live server(s) to persist what is in memory, so the snapshot is current
  await ctlRequest({ type: "flush", pageId: params.pageId });
  const page = await prisma.page.findUniqueOrThrow({ where: { id: params.pageId }, select: { ydocState: true } });
  const state = page.ydocState ? new Uint8Array(page.ydocState) : encodeState(docFromState(null));
  const version = await prisma.pageVersion.create({
    data: { pageId: params.pageId, state: Buffer.from(state), kind: "MANUAL", label: label || null, createdById: user.id },
    select: { id: true, label: true, kind: true, createdAt: true },
  });
  return { version };
});
