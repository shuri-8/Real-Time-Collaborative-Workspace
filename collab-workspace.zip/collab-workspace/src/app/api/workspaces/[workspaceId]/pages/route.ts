import { z } from "zod";
import { Role, hasRole, resolveRole } from "@shared/rbac";
import { HttpError, body, requireUser, route } from "@/lib/api";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

async function membership(workspaceId: string, userId: string) {
  const ws = await prisma.workspace.findUnique({ where: { id: workspaceId }, select: { id: true, name: true, ownerId: true } });
  if (!ws) throw new HttpError(404, "Workspace not found.");
  const member = await prisma.workspaceMember.findUnique({ where: { workspaceId_userId: { workspaceId, userId } } });
  if (ws.ownerId !== userId && !member) throw new HttpError(404, "Workspace not found.");
  return { ws, member };
}

/** Flat list of the pages the user may open, each with the user's effective role. */
export const GET = route(async (_req, { params }) => {
  const user = await requireUser();
  const { ws, member } = await membership(params.workspaceId, user.id);
  const [pages, perms] = await Promise.all([
    prisma.page.findMany({
      where: { workspaceId: ws.id },
      select: { id: true, title: true, icon: true, parentId: true, position: true, createdById: true, updatedAt: true },
      orderBy: [{ position: "asc" }, { createdAt: "asc" }],
    }),
    prisma.pagePermission.findMany({ where: { userId: user.id, page: { workspaceId: ws.id } }, select: { pageId: true, role: true } }),
  ]);
  const byPage = new Map(perms.map((p) => [p.pageId, p.role as Role]));
  const visible = pages
    .map((p) => {
      const a = resolveRole({
        isWorkspaceOwner: ws.ownerId === user.id,
        isPageCreator: p.createdById === user.id,
        membershipRole: member ? ((member.role as Role | null) ?? null) : undefined,
        pageRole: byPage.get(p.id) ?? null,
      });
      return { id: p.id, title: p.title, icon: p.icon, parentId: p.parentId, position: p.position, role: a.role, canManage: a.canManage };
    })
    .filter((p) => p.role);
  const wsRole = ws.ownerId === user.id ? "EDIT" : (member?.role ?? null);
  return { workspace: { id: ws.id, name: ws.name, isOwner: ws.ownerId === user.id, role: wsRole }, pages: visible };
});

export const POST = route(async (req, { params }) => {
  const user = await requireUser();
  const { ws, member } = await membership(params.workspaceId, user.id);
  const wsRole: Role | null = ws.ownerId === user.id ? "EDIT" : ((member?.role as Role | null) ?? null);
  if (!hasRole(wsRole, "EDIT")) throw new HttpError(403, "You need edit access to the workspace to create pages.");
  const data = await body(req, z.object({ title: z.string().trim().max(200).optional(), parentId: z.string().nullable().optional() }));
  if (data.parentId) {
    const parent = await prisma.page.findUnique({ where: { id: data.parentId }, select: { workspaceId: true } });
    if (!parent || parent.workspaceId !== ws.id) throw new HttpError(400, "Parent page is not in this workspace.");
  }
  const siblings = await prisma.page.count({ where: { workspaceId: ws.id, parentId: data.parentId ?? null } });
  const page = await prisma.page.create({
    data: { workspaceId: ws.id, parentId: data.parentId ?? null, title: data.title || "Untitled", position: siblings, createdById: user.id },
    select: { id: true, title: true, icon: true, parentId: true, position: true },
  });
  return { page: { ...page, role: "EDIT" as Role, canManage: true } };
});
