import { z } from "zod";
import { body, requireUser, route } from "@/lib/api";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const user = await requireUser();
  const workspaces = await prisma.workspace.findMany({
    where: { OR: [{ ownerId: user.id }, { members: { some: { userId: user.id } } }] },
    select: { id: true, name: true, ownerId: true },
    orderBy: { createdAt: "asc" },
  });
  return { workspaces };
});

export const POST = route(async (req) => {
  const user = await requireUser();
  const { name } = await body(req, z.object({ name: z.string().trim().min(1).max(80) }));
  const ws = await prisma.workspace.create({
    data: {
      name,
      ownerId: user.id,
      members: { create: { userId: user.id, role: "EDIT" } },
      pages: { create: { title: "Untitled", createdById: user.id } },
    },
    select: { id: true, name: true, ownerId: true, pages: { select: { id: true }, take: 1 } },
  });
  return { workspace: { id: ws.id, name: ws.name, ownerId: ws.ownerId }, firstPageId: ws.pages[0]?.id };
});
