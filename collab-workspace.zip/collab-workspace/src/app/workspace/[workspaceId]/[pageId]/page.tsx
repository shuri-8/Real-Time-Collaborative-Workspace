import WorkspaceShell from "@/components/WorkspaceShell";

export default function Page({ params }: { params: { workspaceId: string; pageId: string } }) {
  return <WorkspaceShell workspaceId={params.workspaceId} pageId={params.pageId} />;
}
