import WorkspaceHome from "@/components/WorkspaceHome";

export default function Page({ params }: { params: { workspaceId: string } }) {
  return <WorkspaceHome workspaceId={params.workspaceId} />;
}
