import { redirect } from "next/navigation";
import { currentUser } from "@/lib/api";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function WorkspaceIndex() {
  const user = await currentUser();
  if (!user) redirect("/login");
  const ws = await prisma.workspace.findFirst({
    where: { OR: [{ ownerId: user.id }, { members: { some: { userId: user.id } } }] },
    orderBy: { createdAt: "asc" },
    select: { id: true },
  });
  if (!ws) redirect("/register");
  redirect(`/workspace/${ws.id}`);
}
