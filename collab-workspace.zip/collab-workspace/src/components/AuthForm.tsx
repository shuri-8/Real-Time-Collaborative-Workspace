"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { api } from "@/lib/client-api";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState(mode === "login" ? "alice@example.com" : "");
  const [password, setPassword] = useState(mode === "login" ? "password123" : "");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const isLogin = mode === "login";

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api(isLogin ? "/api/auth/login" : "/api/auth/register", { method: "POST", json: isLogin ? { email, password } : { name, email, password } });
      router.replace("/workspace");
      router.refresh();
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  }

  const field = "w-full rounded-md border border-ink-200 bg-white px-3 py-2 text-[15px] focus:border-brand";
  return (
    <main className="grid min-h-screen md:grid-cols-[1fr_28rem]">
      <section className="hidden bg-ink-900 p-14 text-ink-100 md:flex md:flex-col md:justify-between">
        <p className="text-sm text-ink-300">Collab Workspace</p>
        <div className="max-w-md">
          <p className="font-doc text-4xl leading-tight">Write together, in the same sentence, at the same time.</p>
          <p className="mt-5 text-ink-300">Pages sync through a CRDT, so edits made offline merge cleanly when you come back.</p>
        </div>
        <p className="text-xs text-ink-500">Yjs · TipTap · Redis · PostgreSQL</p>
      </section>
      <section className="flex items-center justify-center p-8">
        <form onSubmit={submit} className="w-full max-w-sm space-y-4">
          <h1 className="text-2xl font-semibold">{isLogin ? "Sign in" : "Create your account"}</h1>
          {!isLogin && (
            <label className="block text-sm font-medium">
              Name
              <input className={`${field} mt-1`} value={name} onChange={(e) => setName(e.target.value)} required autoComplete="name" />
            </label>
          )}
          <label className="block text-sm font-medium">
            Email
            <input className={`${field} mt-1`} type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
          </label>
          <label className="block text-sm font-medium">
            Password
            <input className={`${field} mt-1`} type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={isLogin ? 1 : 8} autoComplete={isLogin ? "current-password" : "new-password"} />
          </label>
          {error && <p role="alert" className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
          <button disabled={busy} className="w-full rounded-md bg-brand px-4 py-2.5 font-medium text-white hover:bg-brand-dark disabled:opacity-60">
            {busy ? "Please wait…" : isLogin ? "Sign in" : "Create account"}
          </button>
          {isLogin && <p className="text-sm text-ink-500">Demo accounts (password <code>password123</code>): alice, bob, carol, dave @example.com</p>}
          <p className="text-sm text-ink-500">
            {isLogin ? "New here? " : "Already registered? "}
            <Link className="font-medium text-brand underline" href={isLogin ? "/register" : "/login"}>{isLogin ? "Create an account" : "Sign in"}</Link>
          </p>
        </form>
      </section>
    </main>
  );
}
