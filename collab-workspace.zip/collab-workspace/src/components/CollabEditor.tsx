"use client";
import Collaboration from "@tiptap/extension-collaboration";
import CollaborationCursor from "@tiptap/extension-collaboration-cursor";
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import { useEffect, useRef, useState } from "react";
import * as Y from "yjs";
import { canComment, canEdit } from "@shared/rbac";
import { makeAnchor } from "@/lib/anchors";
import { CommentHighlights } from "@/lib/comment-extension";
import type { CollabProvider } from "@/lib/provider";
import type { CommentDTO, Me, PendingAnchor, Role } from "@/lib/types";

interface Props {
  doc: Y.Doc;
  provider: CollabProvider;
  me: Me;
  role: Role;
  comments: CommentDTO[];
  activeCommentId: string | null;
  onStartComment: (a: PendingAnchor) => void;
  onOpenComment: (id: string) => void;
}

export default function CollabEditor({ doc, provider, me, role, comments, activeCommentId, onStartComment, onOpenComment }: Props) {
  const commentsRef = useRef(comments);
  const activeRef = useRef(activeCommentId);
  commentsRef.current = comments;
  activeRef.current = activeCommentId;
  const [bubble, setBubble] = useState<{ x: number; y: number; from: number; to: number; quote: string } | null>(null);

  const editor = useEditor(
    {
      immediatelyRender: false,
      editable: canEdit(role),
      extensions: [
        StarterKit.configure({ history: false }), // Yjs provides undo/redo semantics via the CRDT
        Collaboration.configure({ document: doc }),
        CollaborationCursor.configure({ provider, user: { id: me.id, name: me.name, color: me.color } }),
        CommentHighlights.configure({ getComments: () => commentsRef.current, getActiveId: () => activeRef.current }),
      ],
      editorProps: { attributes: { class: "doc-prose", "aria-label": "Document", spellcheck: "true" } },
    },
    [doc, provider]
  );

  // live role changes (promoted / demoted from the Share modal)
  useEffect(() => {
    editor?.setEditable(canEdit(role));
  }, [editor, role]);

  // redraw comment highlights when the comment list or the active comment changes
  useEffect(() => {
    if (!editor || editor.isDestroyed) return;
    editor.view.dispatch(editor.state.tr.setMeta("commentsChanged", Date.now()));
  }, [editor, comments, activeCommentId]);

  function onSelectionEnd() {
    if (!editor || !canComment(role)) return setBubble(null);
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || sel.rangeCount === 0) return setBubble(null);
    const range = sel.getRangeAt(0);
    if (!editor.view.dom.contains(range.commonAncestorContainer)) return setBubble(null);
    const a = editor.view.posAtDOM(range.startContainer, range.startOffset);
    const b = editor.view.posAtDOM(range.endContainer, range.endOffset);
    const quote = sel.toString().trim().slice(0, 300);
    if (!quote) return setBubble(null);
    const rect = range.getBoundingClientRect();
    setBubble({ x: rect.left + rect.width / 2, y: rect.top, from: Math.min(a, b), to: Math.max(a, b), quote });
  }

  function startComment() {
    if (!editor || !bubble) return;
    const anchor = makeAnchor(editor.state, bubble.from, bubble.to);
    if (anchor) onStartComment({ quote: bubble.quote, ...anchor });
    setBubble(null);
    window.getSelection()?.removeAllRanges();
  }

  const btn = (active: boolean) => `rounded px-2 py-1 text-sm ${active ? "bg-brand text-white" : "hover:bg-ink-100"}`;

  return (
    <div
      onMouseUp={() => setTimeout(onSelectionEnd, 0)}
      onKeyUp={onSelectionEnd}
      onClick={(e) => {
        const id = (e.target as HTMLElement).closest("[data-comment-id]")?.getAttribute("data-comment-id");
        if (id) onOpenComment(id);
      }}
    >
      {editor && canEdit(role) && (
        <div role="toolbar" aria-label="Formatting" className="sticky top-0 z-10 mb-4 flex flex-wrap gap-1 rounded-md border border-ink-100 bg-white/95 p-1 backdrop-blur">
          <button className={btn(editor.isActive("bold"))} onClick={() => editor.chain().focus().toggleBold().run()}><b>B</b></button>
          <button className={btn(editor.isActive("italic"))} onClick={() => editor.chain().focus().toggleItalic().run()}><i>I</i></button>
          <button className={btn(editor.isActive("code"))} onClick={() => editor.chain().focus().toggleCode().run()}>{"</>"}</button>
          <span className="mx-1 w-px bg-ink-100" />
          <button className={btn(editor.isActive("heading", { level: 1 }))} onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}>H1</button>
          <button className={btn(editor.isActive("heading", { level: 2 }))} onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}>H2</button>
          <button className={btn(editor.isActive("bulletList"))} onClick={() => editor.chain().focus().toggleBulletList().run()}>Bullets</button>
          <button className={btn(editor.isActive("orderedList"))} onClick={() => editor.chain().focus().toggleOrderedList().run()}>Numbered</button>
          <button className={btn(editor.isActive("blockquote"))} onClick={() => editor.chain().focus().toggleBlockquote().run()}>Quote</button>
          <button className={btn(editor.isActive("codeBlock"))} onClick={() => editor.chain().focus().toggleCodeBlock().run()}>Code block</button>
          <button className={btn(false)} onClick={() => editor.chain().focus().undo().run()} title="Undo (your own changes only)">Undo</button>
          <button className={btn(false)} onClick={() => editor.chain().focus().redo().run()}>Redo</button>
        </div>
      )}
      {!canEdit(role) && (
        <p className="mb-4 rounded-md bg-ink-50 px-3 py-2 text-sm text-ink-500">
          {role === "COMMENT" ? "You can read and comment on this page. Select text to add a comment." : "You have read-only access to this page."}
        </p>
      )}
      <EditorContent editor={editor} />
      {bubble && (
        <button
          onMouseDown={(e) => e.preventDefault()}
          onClick={startComment}
          className="fixed z-50 -translate-x-1/2 -translate-y-full rounded-md bg-ink-900 px-3 py-1.5 text-sm font-medium text-white shadow-lg"
          style={{ left: bubble.x, top: bubble.y - 8 }}
        >
          Comment
        </button>
      )}
    </div>
  );
}
