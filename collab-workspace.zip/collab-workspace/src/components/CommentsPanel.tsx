"use client";
import { useMemo, useState } from "react";
import { canComment } from "@shared/rbac";
import { api } from "@/lib/client-api";
import type { CommentDTO, PendingAnchor, Role } from "@/lib/types";

interface Props {
  pageId: string;
  role: Role;
  canManage: boolean;
  meId: string;
  comments: CommentDTO[];
  pending: PendingAnchor | null;
  activeId: string | null;
  onActive: (id: string | null) => void;
  onClearPending: () => void;
  onChanged: () => void;
  onClose: () => void;
}

const when = (iso: string) => new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });

export default function CommentsPanel(p: Props) {
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [reply, setReply] = useState("");
  const [showResolved, setShowResolved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const allowed = canComment(p.role);

  const threads = useMemo(() => {
    const top = p.comments.filter((c) => !c.parentId);
    return top
      .filter((c) => showResolved || !c.resolved)
      .map((c) => ({ ...c, replies: p.comments.filter((r) => r.parentId === c.id) }));
  }, [p.comments, showResolved]);

  async function run(fn: () => Promise<unknown>) {
    setError(null);
    try {
      await fn();
      p.onChanged();
    } catch (e) {
      setError((e as Error).message);
    }
  }

  const post = () =>
    run(async () => {
      await api(`/api/pages/${p.pageId}/comments`, { method: "POST", json: { body: draft, quote: p.pending?.quote ?? "", anchorFrom: p.pending?.anchorFrom, anchorTo: p.pending?.anchorTo } });
      setDraft("");
      p.onClearPending();
    });

  const sendReply = (parentId: string) =>
    run(async () => {
      await api(`/api/pages/${p.pageId}/comments`, { method: "POST", json: { body: reply, parentId } });
      setReply("");
      setReplyTo(null);
    });

  return (
    <aside className="flex h-full w-80 shrink-0 flex-col border-l border-ink-100 bg-ink-50" aria-label="Comments">
      <header className="flex items-center justify-between border-b border-ink-100 px-4 py-3">
        <h2 className="font-semibold">Comments</h2>
        <button onClick={p.onClose} aria-label="Close comments" className="rounded px-2 text-ink-500 hover:bg-ink-100">✕</button>
      </header>
      <div className="flex-1 space-y-3 overflow-y-auto p-3">
        {p.pending && allowed && (
          <div className="rounded-md border border-brand bg-white p-3">
            <p className="border-l-2 border-yellow-400 pl-2 text-sm italic text-ink-500">“{p.pending.quote}”</p>
            <textarea autoFocus value={draft} onChange={(e) => setDraft(e.target.value)} rows={3} placeholder="Write a comment" aria-label="New comment" className="mt-2 w-full rounded border border-ink-200 p-2 text-sm" />
            <div className="mt-2 flex justify-end gap-2">
              <button onClick={() => { p.onClearPending(); setDraft(""); }} className="rounded px-3 py-1 text-sm hover:bg-ink-100">Cancel</button>
              <button disabled={!draft.trim()} onClick={post} className="rounded bg-brand px-3 py-1 text-sm font-medium text-white disabled:opacity-50">Comment</button>
            </div>
          </div>
        )}
        {!p.pending && allowed && threads.length === 0 && <p className="px-1 text-sm text-ink-500">Select text in the page to start a thread.</p>}
        {!allowed && <p className="px-1 text-sm text-ink-500">You can read comments but not write them.</p>}
        {error && <p role="alert" className="rounded bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}

        {threads.map((c) => (
          <article key={c.id} onClick={() => p.onActive(c.id)} className={`rounded-md border bg-white p-3 ${p.activeId === c.id ? "border-yellow-500" : "border-ink-100"} ${c.resolved ? "opacity-60" : ""}`}>
            {c.quote && <p className="mb-2 border-l-2 border-yellow-400 pl-2 text-sm italic text-ink-500">“{c.quote}”</p>}
            <Message c={c} />
            {c.replies.map((r) => (
              <div key={r.id} className="mt-3 border-t border-ink-100 pt-2">
                <Message c={r} />
                {(r.author.id === p.meId || p.canManage) && <button onClick={() => run(() => api(`/api/pages/${p.pageId}/comments/${r.id}`, { method: "DELETE" }))} className="mt-1 text-xs text-ink-500 underline">Delete</button>}
              </div>
            ))}
            <div className="mt-2 flex flex-wrap gap-3 text-xs text-ink-500">
              {allowed && <button className="underline" onClick={() => setReplyTo(replyTo === c.id ? null : c.id)}>Reply</button>}
              {allowed && (c.author.id === p.meId || p.role === "EDIT") && (
                <button className="underline" onClick={() => run(() => api(`/api/pages/${p.pageId}/comments/${c.id}`, { method: "PATCH", json: { resolved: !c.resolved } }))}>{c.resolved ? "Reopen" : "Resolve"}</button>
              )}
              {(c.author.id === p.meId || p.canManage) && <button className="underline" onClick={() => run(() => api(`/api/pages/${p.pageId}/comments/${c.id}`, { method: "DELETE" }))}>Delete</button>}
            </div>
            {replyTo === c.id && (
              <div className="mt-2">
                <textarea value={reply} onChange={(e) => setReply(e.target.value)} rows={2} aria-label="Reply" className="w-full rounded border border-ink-200 p-2 text-sm" />
                <button disabled={!reply.trim()} onClick={() => sendReply(c.id)} className="mt-1 rounded bg-brand px-3 py-1 text-sm font-medium text-white disabled:opacity-50">Reply</button>
              </div>
            )}
          </article>
        ))}
      </div>
      <footer className="border-t border-ink-100 px-4 py-2 text-sm">
        <label className="flex items-center gap-2 text-ink-500">
          <input type="checkbox" checked={showResolved} onChange={(e) => setShowResolved(e.target.checked)} /> Show resolved
        </label>
      </footer>
    </aside>
  );
}

function Message({ c }: { c: CommentDTO }) {
  return (
    <div>
      <p className="flex items-center gap-2 text-sm">
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: c.author.color }} />
        <span className="font-medium">{c.author.name}</span>
        <span className="text-xs text-ink-500">{when(c.createdAt)}</span>
      </p>
      <p className="mt-1 whitespace-pre-wrap text-sm">{c.body}</p>
    </div>
  );
}
