"use client";
import { useEffect, useState } from "react";
import type { CollabProvider } from "@/lib/provider";

interface Person {
  id: string;
  name: string;
  color: string;
}

/** Online users (deduplicated across tabs) from the Yjs awareness protocol. */
export default function PresenceStack({ provider, meId }: { provider: CollabProvider; meId: string }) {
  const [people, setPeople] = useState<Person[]>([]);

  useEffect(() => {
    const aw = provider.awareness;
    const update = () => {
      const seen = new Map<string, Person>();
      aw.getStates().forEach((s: Record<string, any>) => {
        const u = s.user;
        if (u?.id && !seen.has(u.id)) seen.set(u.id, { id: u.id, name: u.name, color: u.color });
      });
      setPeople([...seen.values()].sort((a, b) => (a.id === meId ? -1 : b.id === meId ? 1 : a.name.localeCompare(b.name))));
    };
    update();
    aw.on("change", update);
    return () => aw.off("change", update);
  }, [provider, meId]);

  const shown = people.slice(0, 5);
  return (
    <div className="flex items-center gap-2" aria-label={`${people.length} online`}>
      <div className="flex -space-x-2">
        {shown.map((u) => (
          <span key={u.id} title={u.id === meId ? `${u.name} (you)` : u.name} className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-white text-xs font-semibold text-white" style={{ background: u.color }}>
            {u.name.slice(0, 1).toUpperCase()}
          </span>
        ))}
        {people.length > shown.length && (
          <span className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-white bg-ink-200 text-xs font-semibold text-ink-700">+{people.length - shown.length}</span>
        )}
      </div>
      <span className="text-sm text-ink-500">{people.length} online</span>
    </div>
  );
}
