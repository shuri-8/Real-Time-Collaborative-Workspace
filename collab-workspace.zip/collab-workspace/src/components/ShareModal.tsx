"use client";
import { FormEvent, useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client-api";
import type { PersonDTO, Role } from "@/lib/types";

const ROLE_LABEL: Record<Role, string> = { VIEW: "Can view", COMMENT: "Can comment", EDIT: "Can edit" };
const SOURCE_LABEL: Record<PersonDTO["source"], string> = { owner: "Workspace owner", creator: "Page creator", page: "", workspace: "Workspace member" };

export default function ShareModal({ pageId, onClose }: { pageId: string; onClose: () => void }) {
  const [people, setPeople] = useState<PersonDTO[]>([]);
  const [canManage, setCanManage] = useState(false);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("EDIT");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    const r = await api<{ people: PersonDTO[]; canManage: boolean }>(`/api/pages/${pageId}/permissions`);
    setPeople(r.people);
    setCanManage(r.canManage);
  }, [pageId]);

  useEffect(() => {
    load().catch((e) => setError(e.message));
  }, [load]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  async function invite(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setNotice(null);
    try {
      await api(`/api/pages/${pageId}/permissions`, { method: "PUT", json: { email, role } });
      setNotice(`${email} now ${ROLE_LABEL[role].toLowerCase()}.`);
      setEmail("");
      await load();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function change(p: PersonDTO, next: Role) {
    setError(null);
    try {
      await api(`/api/pages/${pageId}/permissions`, { method: "PUT", json: { email: p.email, role: next } });
      await load();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function remove(p: PersonDTO) {
    setError(null);
    try {
      await api(`/api/pages/${pageId}/permissions?userId=${p.userId}`, { method: "DELETE" });
      await load();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-ink-900/50 p-4 pt-24" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-labelledby="share-title" className="w-full max-w-lg rounded-lg bg-white p-6 shadow-xl">
        <div className="flex items-center justify-between">
          <h2 id="share-title" className="text-lg font-semibold">Share this page</h2>
          <button onClick={onClose} aria-label="Close" className="rounded px-2 py-1 text-ink-500 hover:bg-ink-100">✕</button>
        </div>

        {canManage ? (
          <form onSubmit={invite} className="mt-4 flex gap-2">
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email address" aria-label="Email address" className="min-w-0 flex-1 rounded-md border border-ink-200 px-3 py-2 text-sm" />
            <select value={role} onChange={(e) => setRole(e.target.value as Role)} aria-label="Role" className="rounded-md border border-ink-200 px-2 py-2 text-sm">
              {(["VIEW", "COMMENT", "EDIT"] as Role[]).map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
            </select>
            <button className="rounded-md bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand-dark">Invite</button>
          </form>
        ) : (
          <p className="mt-3 text-sm text-ink-500">Only the page creator or workspace owner can change who has access.</p>
        )}
        {error && <p role="alert" className="mt-3 rounded-md bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
        {notice && <p role="status" className="mt-3 rounded-md bg-brand-soft px-3 py-2 text-sm text-brand-dark">{notice}</p>}

        <ul className="mt-5 divide-y divide-ink-100">
          {people.map((p) => {
            const fixed = p.source === "owner" || p.source === "creator";
            return (
              <li key={p.userId} className="flex items-center gap-3 py-2.5">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold text-white" style={{ background: p.color }}>{p.name.slice(0, 1)}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.name}</p>
                  <p className="truncate text-xs text-ink-500">{p.email}{SOURCE_LABEL[p.source] ? ` · ${SOURCE_LABEL[p.source]}` : ""}</p>
                </div>
                {fixed || !canManage ? (
                  <span className="text-sm text-ink-500">{fixed ? "Full access" : ROLE_LABEL[p.role]}</span>
                ) : (
                  <>
                    <select value={p.role} onChange={(e) => change(p, e.target.value as Role)} aria-label={`Role for ${p.name}`} className="rounded-md border border-ink-200 px-2 py-1 text-sm">
                      {(["VIEW", "COMMENT", "EDIT"] as Role[]).map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                    </select>
                    {p.source === "page" && <button onClick={() => remove(p)} className="text-sm text-red-700 underline">Remove</button>}
                  </>
                )}
              </li>
            );
          })}
        </ul>
        <p className="mt-4 text-xs text-ink-500">Changes apply immediately, including to people who have the page open right now.</p>
      </div>
    </div>
  );
}
