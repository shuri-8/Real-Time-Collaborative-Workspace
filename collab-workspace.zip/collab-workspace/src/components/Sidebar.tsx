"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import type { Me, PageNode, WorkspaceSummary } from "@/lib/types";

interface Props {
  me: Me;
  workspaces: WorkspaceSummary[];
  workspaceId: string;
  pages: PageNode[];
  currentPageId: string;
  canCreate: boolean;
  search: string;
  onSwitchWorkspace: (id: string) => void;
  onNewWorkspace: () => void;
  onCreate: (parentId: string | null) => void;
  onDelete: (page: PageNode) => void;
  onLogout: () => void;
}

export default function Sidebar(p: Props) {
  const byParent = useMemo(() => {
    const ids = new Set(p.pages.map((x) => x.id));
    const map = new Map<string | null, PageNode[]>();
    for (const page of p.pages) {
      // pages whose parent is not visible to this user are shown at the top level
      const key = page.parentId && ids.has(page.parentId) ? page.parentId : null;
      map.set(key, [...(map.get(key) ?? []), page]);
    }
    return map;
  }, [p.pages]);

  const ancestors = useMemo(() => {
    const set = new Set<string>();
    const byId = new Map(p.pages.map((x) => [x.id, x]));
    let cur = byId.get(p.currentPageId)?.parentId ?? null;
    while (cur) {
      set.add(cur);
      cur = byId.get(cur)?.parentId ?? null;
    }
    return set;
  }, [p.pages, p.currentPageId]);

  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const isOpen = (id: string) => (id in collapsed ? !collapsed[id] : true) || ancestors.has(id);

  function renderLevel(parent: string | null, depth: number): React.ReactNode {
    const nodes = byParent.get(parent) ?? [];
    return nodes.map((page) => {
      const kids = byParent.get(page.id) ?? [];
      const active = page.id === p.currentPageId;
      return (
        <li key={page.id}>
          <div className={`group flex items-center rounded-md pr-1 ${active ? "bg-white/10 text-white" : "text-ink-300 hover:bg-white/5"}`} style={{ paddingLeft: 6 + depth * 14 }}>
            <button
              aria-label={isOpen(page.id) ? "Collapse" : "Expand"}
              onClick={() => setCollapsed((c) => ({ ...c, [page.id]: isOpen(page.id) }))}
              className={`flex h-6 w-5 items-center justify-center text-xs ${kids.length ? "" : "invisible"}`}
            >
              {isOpen(page.id) ? "▾" : "▸"}
            </button>
            <Link href={`/workspace/${p.workspaceId}/${page.id}${p.search}`} className="min-w-0 flex-1 truncate py-1.5 text-sm" aria-current={active ? "page" : undefined}>
              {page.title || "Untitled"}
            </Link>
            {p.canCreate && (
              <button title="Add a page inside" aria-label={`Add a page inside ${page.title}`} onClick={() => p.onCreate(page.id)} className="h-6 w-6 rounded text-base opacity-0 hover:bg-white/10 focus:opacity-100 group-hover:opacity-100">+</button>
            )}
            {page.canManage && (
              <button title="Delete page" aria-label={`Delete ${page.title}`} onClick={() => p.onDelete(page)} className="h-6 w-6 rounded text-sm opacity-0 hover:bg-white/10 focus:opacity-100 group-hover:opacity-100">×</button>
            )}
          </div>
          {kids.length > 0 && isOpen(page.id) && <ul>{renderLevel(page.id, depth + 1)}</ul>}
        </li>
      );
    });
  }

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col bg-ink-900 text-ink-100">
      <div className="space-y-2 border-b border-white/10 p-3">
        <label className="sr-only" htmlFor="ws-switch">Workspace</label>
        <select
          id="ws-switch"
          value={p.workspaceId}
          onChange={(e) => (e.target.value === "__new" ? p.onNewWorkspace() : p.onSwitchWorkspace(e.target.value))}
          className="w-full rounded-md border border-white/10 bg-ink-700 px-2 py-1.5 text-sm"
        >
          {p.workspaces.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
          <option value="__new">+ New workspace…</option>
        </select>
      </div>
      <nav aria-label="Pages" className="flex-1 overflow-y-auto p-2">
        <ul>{renderLevel(null, 0)}</ul>
        {p.pages.length === 0 && <p className="px-2 py-3 text-sm text-ink-300">No pages yet.</p>}
        {p.canCreate && (
          <button onClick={() => p.onCreate(null)} className="mt-2 w-full rounded-md px-2 py-1.5 text-left text-sm text-ink-300 hover:bg-white/5">+ New page</button>
        )}
      </nav>
      <div className="flex items-center gap-2 border-t border-white/10 p-3">
        <span className="flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold text-white" style={{ background: p.me.color }}>{p.me.name.slice(0, 1)}</span>
        <span className="min-w-0 flex-1 truncate text-sm">{p.me.name}</span>
        <button onClick={p.onLogout} className="text-xs text-ink-300 underline hover:text-white">Sign out</button>
      </div>
    </aside>
  );
}
