"use client";
import { FormEvent, useCallback, useEffect, useState } from "react";
import { canEdit } from "@shared/rbac";
import { api } from "@/lib/client-api";
import type { Role, VersionDTO } from "@/lib/types";

const when = (iso: string) => new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });

export default function VersionDrawer({ pageId, role, onClose }: { pageId: string; role: Role; onClose: () => void }) {
  const [versions, setVersions] = useState<VersionDTO[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [html, setHtml] = useState<string>("");
  const [label, setLabel] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const editable = canEdit(role);

  const load = useCallback(async () => {
    const r = await api<{ versions: VersionDTO[] }>(`/api/pages/${pageId}/versions`);
    setVersions(r.versions);
  }, [pageId]);

  useEffect(() => {
    load().catch((e) => setMsg({ kind: "err", text: e.message }));
  }, [load]);

  useEffect(() => {
    if (!selected) return;
    api<{ html: string }>(`/api/pages/${pageId}/versions/${selected}`)
      .then((v) => setHtml(v.html))
      .catch((e) => setMsg({ kind: "err", text: e.message }));
  }, [selected, pageId]);

  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      await api(`/api/pages/${pageId}/versions`, { method: "POST", json: { label } });
      setLabel("");
      setMsg({ kind: "ok", text: "Version saved." });
      await load();
    } catch (err) {
      setMsg({ kind: "err", text: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  async function restore() {
    if (!selected || !confirm("Restore this version? Everyone editing the page will see the change. The current text is saved as a version first.")) return;
    setBusy(true);
    setMsg(null);
    try {
      await api(`/api/pages/${pageId}/versions/${selected}/restore`, { method: "POST" });
      setMsg({ kind: "ok", text: "Version restored." });
      await load();
    } catch (err) {
      setMsg({ kind: "err", text: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <aside className="flex h-full w-96 shrink-0 flex-col border-l border-ink-100 bg-ink-50" aria-label="Version history">
      <header className="flex items-center justify-between border-b border-ink-100 px-4 py-3">
        <h2 className="font-semibold">Version history</h2>
        <button onClick={onClose} aria-label="Close version history" className="rounded px-2 text-ink-500 hover:bg-ink-100">✕</button>
      </header>
      {editable && (
        <form onSubmit={save} className="flex gap-2 border-b border-ink-100 p-3">
          <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Name this version (optional)" aria-label="Version name" className="min-w-0 flex-1 rounded border border-ink-200 px-2 py-1.5 text-sm" />
          <button disabled={busy} className="rounded bg-brand px-3 py-1.5 text-sm font-medium text-white disabled:opacity-60">Save version</button>
        </form>
      )}
      {msg && <p role={msg.kind === "err" ? "alert" : "status"} className={`mx-3 mt-3 rounded px-3 py-2 text-sm ${msg.kind === "err" ? "bg-red-50 text-red-800" : "bg-brand-soft text-brand-dark"}`}>{msg.text}</p>}
      <ul className="max-h-60 divide-y divide-ink-100 overflow-y-auto border-b border-ink-100">
        {versions.length === 0 && <li className="p-4 text-sm text-ink-500">No versions yet. Versions are saved automatically when everyone leaves a page, and whenever you press Save version.</li>}
        {versions.map((v) => (
          <li key={v.id}>
            <button onClick={() => setSelected(v.id)} className={`w-full px-4 py-2.5 text-left ${selected === v.id ? "bg-white" : "hover:bg-white/60"}`}>
              <p className="text-sm font-medium">{v.label || (v.kind === "AUTO" ? "Auto-saved" : "Saved version")}</p>
              <p className="text-xs text-ink-500">{when(v.createdAt)}{v.createdBy ? ` · ${v.createdBy.name}` : ""}{v.kind === "AUTO" ? " · automatic" : ""}</p>
            </button>
          </li>
        ))}
      </ul>
      <div className="flex-1 overflow-y-auto p-4">
        {selected ? (
          <>
            <p className="mb-2 text-xs text-ink-500">Preview (read-only)</p>
            <div className="version-preview rounded-md border border-ink-100 bg-white p-4 text-sm" dangerouslySetInnerHTML={{ __html: html }} />
            {editable && <button onClick={restore} disabled={busy} className="mt-4 w-full rounded-md bg-ink-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-60">Restore this version</button>}
          </>
        ) : (
          <p className="text-sm text-ink-500">Choose a version to preview it.</p>
        )}
      </div>
    </aside>
  );
}
