"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { api } from "@/lib/client-api";
import type { PageNode } from "@/lib/types";

/** Opens the first page of a workspace, or offers to create one. */
export default function WorkspaceHome({ workspaceId }: { workspaceId: string }) {
  const router = useRouter();
  const [state, setState] = useState<"loading" | "empty" | "error">("loading");
  const [canCreate, setCanCreate] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    api<{ pages: PageNode[]; workspace: { role: string | null } }>(`/api/workspaces/${workspaceId}/pages`)
      .then(({ pages, workspace }) => {
        const first = pages.find((p) => !p.parentId) ?? pages[0];
        if (first) router.replace(`/workspace/${workspaceId}/${first.id}`);
        else {
          setCanCreate(workspace.role === "EDIT");
          setState("empty");
        }
      })
      .catch((e) => {
        setMessage(e.message);
        setState("error");
      });
  }, [workspaceId, router]);

  async function create() {
    const { page } = await api<{ page: PageNode }>(`/api/workspaces/${workspaceId}/pages`, { method: "POST", json: {} });
    router.replace(`/workspace/${workspaceId}/${page.id}`);
  }

  if (state === "loading") return <p className="p-10 text-ink-500">Opening workspace…</p>;
  if (state === "error") return <p className="p-10 text-red-700">{message}</p>;
  return (
    <main className="mx-auto max-w-md p-16 text-center">
      <h1 className="text-xl font-semibold">This workspace has no pages yet</h1>
      {canCreate ? (
        <button onClick={create} className="mt-5 rounded-md bg-brand px-4 py-2 font-medium text-white hover:bg-brand-dark">Create the first page</button>
      ) : (
        <p className="mt-3 text-ink-500">Ask the owner to share a page with you.</p>
      )}
    </main>
  );
}
