"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { canEdit } from "@shared/rbac";
import { ApiError, api } from "@/lib/client-api";
import { useCollab } from "@/lib/use-collab";
import type { CommentDTO, Me, PageNode, PendingAnchor, Role, WorkspaceSummary } from "@/lib/types";
import CollabEditor from "./CollabEditor";
import CommentsPanel from "./CommentsPanel";
import PresenceStack from "./PresenceStack";
import ShareModal from "./ShareModal";
import Sidebar from "./Sidebar";
import VersionDrawer from "./VersionDrawer";

type Panel = "comments" | "history" | null;

export default function WorkspaceShell({ workspaceId, pageId }: { workspaceId: string; pageId: string }) {
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);
  const [workspaces, setWorkspaces] = useState<WorkspaceSummary[]>([]);
  const [pages, setPages] = useState<PageNode[]>([]);
  const [wsRole, setWsRole] = useState<Role | null>(null);
  const [pageMeta, setPageMeta] = useState<{ title: string; role: Role; canManage: boolean } | null>(null);
  const [title, setTitle] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [panel, setPanel] = useState<Panel>(null);
  const [shareOpen, setShareOpen] = useState(false);
  const [offline, setOffline] = useState(false);
  const [comments, setComments] = useState<CommentDTO[]>([]);
  const [pending, setPending] = useState<PendingAnchor | null>(null);
  const [activeComment, setActiveComment] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const titleFocused = useRef(false);

  const collab = useCollab(pageId, me);

  useEffect(() => setSearch(window.location.search), [pageId]);

  /* ---------------------------------- data ---------------------------------- */
  useEffect(() => {
    Promise.all([api<{ user: Me }>("/api/auth/me"), api<{ workspaces: WorkspaceSummary[] }>("/api/workspaces")])
      .then(([m, w]) => {
        setMe(m.user);
        setWorkspaces(w.workspaces);
      })
      .catch(() => router.replace("/login"));
  }, [router]);

  const loadPages = useCallback(async () => {
    const r = await api<{ pages: PageNode[]; workspace: { role: Role | null } }>(`/api/workspaces/${workspaceId}/pages`);
    setPages(r.pages);
    setWsRole(r.workspace.role);
  }, [workspaceId]);

  useEffect(() => {
    loadPages().catch((e) => setError(e.message));
    const t = setInterval(() => loadPages().catch(() => {}), 8000);
    return () => clearInterval(t);
  }, [loadPages]);

  useEffect(() => {
    setError(null);
    setPageMeta(null);
    setPanel(null);
    setPending(null);
    setActiveComment(null);
    setOffline(false);
    api<{ page: { title: string }; role: Role; canManage: boolean }>(`/api/pages/${pageId}`)
      .then((r) => {
        setPageMeta({ title: r.page.title, role: r.role, canManage: r.canManage });
        setTitle(r.page.title);
      })
      .catch((e: ApiError) => setError(e.status === 404 ? "This page doesn't exist, or you don't have access to it." : e.message));
  }, [pageId]);

  // keep the title input in sync with renames made by other people
  useEffect(() => {
    const cur = pages.find((p) => p.id === pageId);
    if (cur && !titleFocused.current) setTitle(cur.title);
  }, [pages, pageId]);

  const loadComments = useCallback(async () => {
    const r = await api<{ comments: CommentDTO[] }>(`/api/pages/${pageId}/comments`);
    setComments(r.comments);
  }, [pageId]);

  useEffect(() => {
    setComments([]);
    if (!pageMeta) return;
    loadComments().catch(() => {});
    const t = setInterval(() => loadComments().catch(() => {}), 4000);
    return () => clearInterval(t);
  }, [loadComments, pageMeta]);

  /* --------------------------------- actions -------------------------------- */
  async function createPage(parentId: string | null) {
    try {
      const { page } = await api<{ page: PageNode }>(`/api/workspaces/${workspaceId}/pages`, { method: "POST", json: { parentId } });
      await loadPages();
      router.push(`/workspace/${workspaceId}/${page.id}${search}`);
    } catch (e) {
      alert((e as Error).message);
    }
  }

  async function deletePage(page: PageNode) {
    if (!confirm(`Delete “${page.title || "Untitled"}” and all pages inside it?`)) return;
    try {
      await api(`/api/pages/${page.id}`, { method: "DELETE" });
      await loadPages();
      if (page.id === pageId) router.push(`/workspace/${workspaceId}`);
    } catch (e) {
      alert((e as Error).message);
    }
  }

  async function saveTitle() {
    titleFocused.current = false;
    if (!pageMeta || title === pages.find((p) => p.id === pageId)?.title) return;
    try {
      await api(`/api/pages/${pageId}`, { method: "PATCH", json: { title } });
      await loadPages();
    } catch (e) {
      setError((e as Error).message);
    }
  }

  async function logout() {
    await api("/api/auth/logout", { method: "POST" });
    router.replace("/login");
    router.refresh();
  }

  async function newWorkspace() {
    const name = prompt("Name your new workspace");
    if (!name?.trim()) return;
    const r = await api<{ workspace: WorkspaceSummary; firstPageId: string }>("/api/workspaces", { method: "POST", json: { name } });
    router.push(`/workspace/${r.workspace.id}/${r.firstPageId}`);
  }

  function toggleOffline() {
    if (!collab) return;
    if (offline) collab.provider.connect();
    else collab.provider.disconnect();
    setOffline(!offline);
  }

  /* ---------------------------------- view ---------------------------------- */
  if (error) {
    return (
      <main className="mx-auto max-w-md p-16 text-center">
        <p className="text-lg font-medium">{error}</p>
        <Link href={`/workspace/${workspaceId}`} className="mt-4 inline-block text-brand underline">Back to the workspace</Link>
      </main>
    );
  }
  if (!me || !pageMeta) return <p className="p-10 text-ink-500">Loading…</p>;

  const role: Role = collab?.role ?? pageMeta.role;
  const unresolved = comments.filter((c) => !c.parentId && !c.resolved).length;
  const statusText = offline || collab?.status === "disconnected" ? "Offline: edits are kept and will merge" : collab?.status === "connecting" ? "Connecting…" : collab?.status === "denied" ? "Access removed" : collab?.synced ? `Synced · ws${collab.server}` : "Syncing…";
  const statusColor = collab?.status === "connected" && collab.synced ? "bg-emerald-500" : collab?.status === "denied" ? "bg-red-500" : "bg-amber-500";
  const headerBtn = (on: boolean) => `rounded-md px-3 py-1.5 text-sm ${on ? "bg-ink-100 font-medium" : "hover:bg-ink-50"}`;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar
        me={me}
        workspaces={workspaces}
        workspaceId={workspaceId}
        pages={pages}
        currentPageId={pageId}
        canCreate={canEdit(wsRole)}
        search={search}
        onSwitchWorkspace={(id) => router.push(`/workspace/${id}`)}
        onNewWorkspace={newWorkspace}
        onCreate={createPage}
        onDelete={deletePage}
        onLogout={logout}
      />
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex flex-wrap items-center gap-3 border-b border-ink-100 px-6 py-2.5">
          <input
            value={title}
            disabled={!canEdit(role)}
            onFocus={() => (titleFocused.current = true)}
            onChange={(e) => setTitle(e.target.value)}
            onBlur={saveTitle}
            onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
            aria-label="Page title"
            placeholder="Untitled"
            className="min-w-0 flex-1 bg-transparent text-lg font-semibold focus:outline-none disabled:opacity-100"
          />
          {collab && <PresenceStack provider={collab.provider} meId={me.id} />}
          <span className="flex items-center gap-2 text-sm text-ink-500" role="status">
            <span className={`h-2 w-2 rounded-full ${statusColor}`} />
            {statusText}
          </span>
          {!canEdit(role) && <span className="rounded bg-ink-100 px-2 py-0.5 text-xs font-medium">{role === "COMMENT" ? "Comment only" : "View only"}</span>}
          <button onClick={toggleOffline} className={headerBtn(offline)} title="Simulate a lost connection to test offline merging">
            {offline ? "Reconnect" : "Go offline"}
          </button>
          <button onClick={() => setPanel(panel === "comments" ? null : "comments")} className={headerBtn(panel === "comments")}>
            Comments{unresolved ? ` (${unresolved})` : ""}
          </button>
          <button onClick={() => setPanel(panel === "history" ? null : "history")} className={headerBtn(panel === "history")}>History</button>
          <button onClick={() => setShareOpen(true)} className="rounded-md bg-brand px-4 py-1.5 text-sm font-medium text-white hover:bg-brand-dark">Share</button>
        </header>

        <div className="flex min-h-0 flex-1">
          <main className="flex-1 overflow-y-auto">
            <div className="mx-auto max-w-3xl px-8 py-10">
              {collab?.denied && <p role="alert" className="mb-4 rounded-md bg-red-50 px-3 py-2 text-sm text-red-800">{collab.denied}</p>}
              {collab && (
                <CollabEditor
                  key={pageId}
                  doc={collab.doc}
                  provider={collab.provider}
                  me={me}
                  role={role}
                  comments={comments}
                  activeCommentId={activeComment}
                  onStartComment={(a) => {
                    setPending(a);
                    setPanel("comments");
                  }}
                  onOpenComment={(id) => {
                    setActiveComment(id);
                    setPanel("comments");
                  }}
                />
              )}
            </div>
          </main>
          {panel === "comments" && (
            <CommentsPanel
              pageId={pageId}
              role={role}
              canManage={pageMeta.canManage}
              meId={me.id}
              comments={comments}
              pending={pending}
              activeId={activeComment}
              onActive={setActiveComment}
              onClearPending={() => setPending(null)}
              onChanged={() => loadComments().catch(() => {})}
              onClose={() => setPanel(null)}
            />
          )}
          {panel === "history" && <VersionDrawer pageId={pageId} role={role} onClose={() => setPanel(null)} />}
        </div>
      </div>
      {shareOpen && <ShareModal pageId={pageId} onClose={() => setShareOpen(false)} />}
    </div>
  );
}
