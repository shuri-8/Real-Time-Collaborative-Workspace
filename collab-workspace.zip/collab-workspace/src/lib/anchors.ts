import * as Y from "yjs";
import { absolutePositionToRelativePosition, relativePositionToAbsolutePosition, ySyncPluginKey } from "y-prosemirror";

/*
 * Comment anchors are stored as Yjs RELATIVE positions. They are attached to CRDT items rather than to
 * character offsets, so they keep pointing at the same text while other people type around it.
 */

export function makeAnchor(state: unknown, from: number, to: number) {
  const ys: any = ySyncPluginKey.getState(state as any);
  if (!ys?.binding) return null;
  const a = absolutePositionToRelativePosition(from, ys.type, ys.binding.mapping);
  const b = absolutePositionToRelativePosition(to, ys.type, ys.binding.mapping);
  return { anchorFrom: Y.relativePositionToJSON(a), anchorTo: Y.relativePositionToJSON(b) };
}

export function resolveAnchor(state: unknown, anchorFrom: unknown, anchorTo: unknown): { from: number; to: number } | null {
  if (!anchorFrom || !anchorTo) return null;
  const ys: any = ySyncPluginKey.getState(state as any);
  if (!ys?.binding) return null;
  try {
    const from = relativePositionToAbsolutePosition(ys.doc, ys.type, Y.createRelativePositionFromJSON(anchorFrom), ys.binding.mapping);
    const to = relativePositionToAbsolutePosition(ys.doc, ys.type, Y.createRelativePositionFromJSON(anchorTo), ys.binding.mapping);
    if (from == null || to == null || to <= from) return null;
    return { from, to };
  } catch {
    return null;
  }
}
