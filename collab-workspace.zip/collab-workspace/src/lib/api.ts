import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { ZodError, ZodTypeAny, z } from "zod";
import { COOKIE_NAME, verifyToken } from "@shared/auth-token";
import { getPageAccess } from "@shared/access";
import { Role, hasRole } from "@shared/rbac";
import { prisma } from "./prisma";

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

type Handler = (req: Request, ctx: { params: Record<string, string> }) => Promise<unknown>;

/** Wraps a route handler: JSON in/out, uniform error responses. */
export function route(fn: Handler) {
  return async (req: Request, ctx: { params: Record<string, string> }) => {
    try {
      const out = await fn(req, ctx);
      if (out instanceof Response) return out;
      return NextResponse.json(out ?? { ok: true });
    } catch (e) {
      if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
      if (e instanceof ZodError) {
        return NextResponse.json({ error: e.issues.map((i) => `${i.path.join(".") || "body"}: ${i.message}`).join("; ") }, { status: 400 });
      }
      console.error(e);
      return NextResponse.json({ error: "Something went wrong on our side." }, { status: 500 });
    }
  };
}

export async function body<S extends ZodTypeAny>(req: Request, schema: S): Promise<z.infer<S>> {
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    throw new HttpError(400, "Request body must be valid JSON.");
  }
  return schema.parse(json);
}

export async function currentUser() {
  const payload = await verifyToken(cookies().get(COOKIE_NAME)?.value);
  if (!payload) return null;
  return prisma.user.findUnique({ where: { id: payload.sub }, select: { id: true, email: true, name: true, color: true } });
}

export async function requireUser() {
  const u = await currentUser();
  if (!u) throw new HttpError(401, "Sign in to continue.");
  return u;
}

/** Load effective access for a page and enforce a minimum role (404 when the user has no access at all). */
export async function requirePage(userId: string, pageId: string, min: Role) {
  const a = await getPageAccess(prisma, userId, pageId);
  if (!a || !a.role) throw new HttpError(404, "Page not found.");
  if (!hasRole(a.role, min)) throw new HttpError(403, `This needs ${min.toLowerCase()} access.`);
  return a as typeof a & { role: Role };
}

const COLORS = ["#d9480f", "#0b7285", "#5f3dc4", "#2b8a3e", "#c2255c", "#1971c2", "#e67700", "#364fc7", "#087f5b", "#a61e4d"];
export const randomColor = () => COLORS[Math.floor(Math.random() * COLORS.length)];

export function setAuthCookie(res: NextResponse, token: string, maxAge: number) {
  res.cookies.set("cw_token", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE === "true",
    path: "/",
    maxAge,
  });
}
