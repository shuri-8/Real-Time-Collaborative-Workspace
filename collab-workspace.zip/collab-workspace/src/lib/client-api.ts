export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

type Init = Omit<RequestInit, "body"> & { json?: unknown };

/** Tiny fetch wrapper: JSON in, JSON out, throws ApiError with the server's message. */
export async function api<T = unknown>(url: string, init: Init = {}): Promise<T> {
  const { json, headers, ...rest } = init;
  const res = await fetch(url, {
    credentials: "same-origin",
    ...rest,
    headers: { ...(json !== undefined ? { "content-type": "application/json" } : {}), ...headers },
    body: json !== undefined ? JSON.stringify(json) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, (data as { error?: string }).error ?? res.statusText);
  return data as T;
}
