import { Extension } from "@tiptap/core";
import { Plugin, PluginKey } from "@tiptap/pm/state";
import { Decoration, DecorationSet } from "@tiptap/pm/view";
import type { CommentDTO } from "./types";
import { resolveAnchor } from "./anchors";

export interface CommentHighlightOptions {
  getComments: () => CommentDTO[];
  getActiveId: () => string | null;
}

/** Paints unresolved, anchored comments as highlights (decorations only: the document is never modified). */
export const CommentHighlights = Extension.create<CommentHighlightOptions>({
  name: "commentHighlights",
  addOptions() {
    return { getComments: () => [], getActiveId: () => null };
  },
  addProseMirrorPlugins() {
    const { getComments, getActiveId } = this.options;
    return [
      new Plugin({
        key: new PluginKey("commentHighlights"),
        props: {
          decorations(state) {
            const decos: Decoration[] = [];
            const active = getActiveId();
            const size = state.doc.content.size;
            for (const c of getComments()) {
              if (c.parentId || c.resolved) continue;
              const r = resolveAnchor(state, c.anchorFrom, c.anchorTo);
              if (!r || r.from < 0 || r.to > size) continue;
              decos.push(
                Decoration.inline(r.from, r.to, {
                  class: c.id === active ? "cm-comment cm-comment-active" : "cm-comment",
                  "data-comment-id": c.id,
                })
              );
            }
            return DecorationSet.create(state.doc, decos);
          },
        },
      }),
    ];
  },
});
