import { randomUUID } from "node:crypto";
import { redis } from "./redis";
import { CTL_CHANNEL } from "@shared/protocol";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export type CtlMessage =
  | { type: "refresh-perms"; pageId: string }
  | { type: "flush"; pageId: string }
  | { type: "restore"; pageId: string; versionId: string };

/**
 * Send a command to the WebSocket servers that currently host the page's room.
 *  - "none"    nobody is editing the page: the caller can work on the database directly
 *  - "acked"   a WebSocket server did the work (flush / restore)
 *  - "timeout" a room is registered in Redis but no server answered in time
 */
export async function ctlRequest(msg: CtlMessage, waitForAck = true): Promise<"none" | "acked" | "timeout"> {
  const hosts = await redis.scard(`rooms:${msg.pageId}`).catch(() => 0);
  if (!hosts) return "none";
  const opId = randomUUID();
  await redis.publish(CTL_CHANNEL, JSON.stringify({ ...msg, opId }));
  if (!waitForAck) return "acked";
  for (let i = 0; i < 30; i++) {
    if (await redis.get(`ack:${opId}`)) return "acked";
    await sleep(100);
  }
  return "timeout";
}

/** Fire-and-forget: tell live connections to re-check their role (best effort). */
export async function notifyPermissionsChanged(pageId: string) {
  await redis.publish(CTL_CHANNEL, JSON.stringify({ type: "refresh-perms", pageId, opId: randomUUID() })).catch(() => {});
}
