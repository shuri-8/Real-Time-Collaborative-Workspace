import * as Y from "yjs";
import * as syncProtocol from "y-protocols/sync";
import * as awarenessProtocol from "y-protocols/awareness";
import * as encoding from "lib0/encoding";
import * as decoding from "lib0/decoding";
import { MSG, SYNC } from "@shared/protocol";
import type { Role } from "@shared/rbac";

export type ProviderStatus = "connecting" | "connected" | "disconnected" | "denied";

type Events = {
  status: (s: ProviderStatus) => void;
  role: (r: Role) => void;
  synced: (v: boolean) => void;
  denied: (reason: string) => void;
};

/**
 * Browser WebSocket provider for the collab server (binary y-protocols framing + role message).
 *
 * Offline behaviour: the Y.Doc keeps accepting local edits while the socket is down. On reconnect we
 * send sync step 1 and the server answers with step 2 — both sides exchange exactly what the other
 * is missing, so offline edits merge without conflicts.
 */
export class CollabProvider {
  readonly awareness: awarenessProtocol.Awareness;
  status: ProviderStatus = "disconnected";
  role: Role | null = null;
  synced = false;
  private ws: WebSocket | null = null;
  private wantConnection = false;
  private retry = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private listeners: { [K in keyof Events]: Set<Events[K]> } = { status: new Set(), role: new Set(), synced: new Set(), denied: new Set() };

  constructor(private url: string, readonly doc: Y.Doc) {
    this.awareness = new awarenessProtocol.Awareness(doc);
    doc.on("update", this.onDocUpdate);
    this.awareness.on("update", this.onAwarenessUpdate);
    if (typeof window !== "undefined") window.addEventListener("beforeunload", this.onUnload);
  }

  on<K extends keyof Events>(ev: K, fn: Events[K]) {
    (this.listeners[ev] as Set<Events[K]>).add(fn);
    return () => (this.listeners[ev] as Set<Events[K]>).delete(fn);
  }
  private emit<K extends keyof Events>(ev: K, ...args: Parameters<Events[K]>) {
    (this.listeners[ev] as Set<(...a: any[]) => void>).forEach((f) => f(...args));
  }
  private setStatus(s: ProviderStatus) {
    if (this.status === s) return;
    this.status = s;
    this.emit("status", s);
  }

  connect() {
    this.wantConnection = true;
    if (this.ws) return;
    this.setStatus("connecting");
    const ws = new WebSocket(this.url);
    ws.binaryType = "arraybuffer";
    this.ws = ws;
    ws.onopen = () => {
      this.retry = 0;
      this.setStatus("connected");
      this.send(this.syncStep1());
      if (this.awareness.getLocalState() !== null) {
        this.send(this.awarenessMessage([this.doc.clientID]));
      }
    };
    ws.onmessage = (ev) => this.receive(new Uint8Array(ev.data as ArrayBuffer));
    ws.onclose = (ev) => {
      this.ws = null;
      this.setSynced(false);
      // forget everybody else's presence; it is re-sent when we reconnect
      awarenessProtocol.removeAwarenessStates(
        this.awareness,
        [...this.awareness.getStates().keys()].filter((c) => c !== this.doc.clientID),
        this
      );
      if (ev.code === 4403) {
        this.wantConnection = false;
        this.setStatus("denied");
        this.emit("denied", ev.reason || "Access revoked");
        return;
      }
      this.setStatus("disconnected");
      if (this.wantConnection) {
        const delay = Math.min(5000, 300 * 2 ** this.retry++);
        this.timer = setTimeout(() => this.connect(), delay);
      }
    };
    ws.onerror = () => ws.close();
  }

  /** Drop the connection on purpose (used by the "Go offline" demo button). */
  disconnect() {
    this.wantConnection = false;
    if (this.timer) clearTimeout(this.timer);
    this.ws?.close();
    if (!this.ws) this.setStatus("disconnected");
  }

  destroy() {
    this.disconnect();
    if (typeof window !== "undefined") window.removeEventListener("beforeunload", this.onUnload);
    awarenessProtocol.removeAwarenessStates(this.awareness, [this.doc.clientID], "destroy");
    this.doc.off("update", this.onDocUpdate);
    this.awareness.destroy();
    this.listeners = { status: new Set(), role: new Set(), synced: new Set(), denied: new Set() };
  }

  get isOpen() {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  /* ------------------------------- wire format ------------------------------- */

  private send(data: Uint8Array) {
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(data);
  }

  private syncStep1() {
    const e = encoding.createEncoder();
    encoding.writeVarUint(e, MSG.SYNC);
    syncProtocol.writeSyncStep1(e, this.doc);
    return encoding.toUint8Array(e);
  }

  private awarenessMessage(clients: number[]) {
    const e = encoding.createEncoder();
    encoding.writeVarUint(e, MSG.AWARENESS);
    encoding.writeVarUint8Array(e, awarenessProtocol.encodeAwarenessUpdate(this.awareness, clients));
    return encoding.toUint8Array(e);
  }

  private setSynced(v: boolean) {
    if (this.synced === v) return;
    this.synced = v;
    this.emit("synced", v);
  }

  private receive(data: Uint8Array) {
    const dec = decoding.createDecoder(data);
    const type = decoding.readVarUint(dec);
    if (type === MSG.SYNC) {
      const enc = encoding.createEncoder();
      encoding.writeVarUint(enc, MSG.SYNC);
      const sub = syncProtocol.readSyncMessage(dec, enc, this.doc, this);
      if (sub === SYNC.STEP2) this.setSynced(true);
      if (encoding.length(enc) > 1) this.send(encoding.toUint8Array(enc));
    } else if (type === MSG.AWARENESS) {
      awarenessProtocol.applyAwarenessUpdate(this.awareness, decoding.readVarUint8Array(dec), this);
    } else if (type === MSG.AUTH) {
      const { role } = JSON.parse(decoding.readVarString(dec)) as { role: Role };
      this.role = role;
      this.emit("role", role);
    } else if (type === MSG.DENIED) {
      this.emit("denied", decoding.readVarString(dec));
    }
  }

  private onDocUpdate = (update: Uint8Array, origin: unknown) => {
    if (origin === this || this.role !== "EDIT") return; // read-only roles never send mutations
    const e = encoding.createEncoder();
    encoding.writeVarUint(e, MSG.SYNC);
    syncProtocol.writeUpdate(e, update);
    this.send(encoding.toUint8Array(e));
  };

  private onAwarenessUpdate = (
    { added, updated, removed }: { added: number[]; updated: number[]; removed: number[] },
    origin: unknown
  ) => {
    if (origin === this) return;
    this.send(this.awarenessMessage(added.concat(updated, removed)));
  };

  private onUnload = () => {
    awarenessProtocol.removeAwarenessStates(this.awareness, [this.doc.clientID], "window unload");
  };
}
