import type { Role } from "@shared/rbac";
export type { Role };

export interface Me {
  id: string;
  name: string;
  email: string;
  color: string;
}

export interface PageNode {
  id: string;
  title: string;
  icon: string | null;
  parentId: string | null;
  position: number;
  role: Role;
  canManage: boolean;
}

export interface WorkspaceSummary {
  id: string;
  name: string;
  ownerId: string;
}

export interface CommentDTO {
  id: string;
  parentId: string | null;
  body: string;
  quote: string;
  anchorFrom: unknown;
  anchorTo: unknown;
  resolved: boolean;
  createdAt: string;
  author: { id: string; name: string; color: string };
}

export interface VersionDTO {
  id: string;
  label: string | null;
  kind: "MANUAL" | "AUTO";
  createdAt: string;
  createdBy: { id: string; name: string } | null;
}

export interface PersonDTO {
  userId: string;
  name: string;
  email: string;
  color: string;
  role: Role;
  source: "owner" | "creator" | "page" | "workspace";
}

export interface PendingAnchor {
  quote: string;
  anchorFrom: unknown;
  anchorTo: unknown;
}
