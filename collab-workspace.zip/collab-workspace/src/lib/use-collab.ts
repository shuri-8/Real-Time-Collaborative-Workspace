"use client";
import { useEffect, useState } from "react";
import * as Y from "yjs";
import type { Role } from "@shared/rbac";
import { CollabProvider, ProviderStatus } from "./provider";
import type { Me } from "./types";

function wsBase(): { url: string; label: string } {
  const urls = (process.env.NEXT_PUBLIC_WS_URLS ?? "ws://localhost:4001,ws://localhost:4002")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const q = new URLSearchParams(window.location.search).get("ws");
  let idx: number;
  if (q && Number(q) >= 1 && Number(q) <= urls.length) {
    idx = Number(q) - 1; // ?ws=1 -> first server, ?ws=2 -> second server
  } else {
    const saved = sessionStorage.getItem("cw_ws");
    idx = saved !== null ? Number(saved) : Math.floor(Math.random() * urls.length);
  }
  sessionStorage.setItem("cw_ws", String(idx));
  const url = urls[idx] ?? urls[0];
  return { url, label: `:${new URL(url.replace(/^ws/, "http")).port || "80"}` };
}

export interface CollabState {
  doc: Y.Doc;
  provider: CollabProvider;
  status: ProviderStatus;
  role: Role | null;
  synced: boolean;
  server: string;
  denied: string | null;
}

/** Creates the Y.Doc + provider for a page and exposes connection state to React. */
export function useCollab(pageId: string, me: Me | null): CollabState | null {
  const [ctx, setCtx] = useState<{ doc: Y.Doc; provider: CollabProvider; server: string } | null>(null);
  const [status, setStatus] = useState<ProviderStatus>("connecting");
  const [role, setRole] = useState<Role | null>(null);
  const [synced, setSynced] = useState(false);
  const [denied, setDenied] = useState<string | null>(null);

  useEffect(() => {
    if (!me) return;
    const { url, label } = wsBase();
    const doc = new Y.Doc();
    const provider = new CollabProvider(`${url}/${encodeURIComponent(pageId)}`, doc);
    provider.awareness.setLocalStateField("user", { id: me.id, name: me.name, color: me.color });
    const offs = [
      provider.on("status", setStatus),
      provider.on("role", setRole),
      provider.on("synced", setSynced),
      provider.on("denied", setDenied),
    ];
    setStatus("connecting");
    setRole(null);
    setSynced(false);
    setDenied(null);
    provider.connect();
    setCtx({ doc, provider, server: label });
    return () => {
      offs.forEach((off) => off());
      provider.destroy();
      doc.destroy();
      setCtx(null);
    };
  }, [pageId, me?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!ctx) return null;
  return { ...ctx, status, role, synced, denied };
}
