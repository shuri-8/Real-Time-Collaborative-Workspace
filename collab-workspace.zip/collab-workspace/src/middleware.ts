import { NextRequest, NextResponse } from "next/server";
import { COOKIE_NAME, verifyToken } from "@shared/auth-token";

export async function middleware(req: NextRequest) {
  const signedIn = !!(await verifyToken(req.cookies.get(COOKIE_NAME)?.value));
  const { pathname } = req.nextUrl;
  if (pathname.startsWith("/workspace") && !signedIn) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if ((pathname === "/login" || pathname === "/register") && signedIn) {
    return NextResponse.redirect(new URL("/workspace", req.url));
  }
  return NextResponse.next();
}

export const config = { matcher: ["/workspace/:path*", "/login", "/register"] };
