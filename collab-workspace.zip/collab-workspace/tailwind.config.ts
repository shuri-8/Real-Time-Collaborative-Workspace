import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: { 900: "#161c26", 700: "#2d3748", 500: "#5b6677", 300: "#aab2bf", 200: "#d5dae2", 100: "#e8ebf0", 50: "#f4f6f9" },
        brand: { DEFAULT: "#0b6e5f", dark: "#08564a", soft: "#dff1ed" },
      },
      fontFamily: {
        sans: ['ui-sans-serif', 'system-ui', '-apple-system', '"Segoe UI"', 'Roboto', 'sans-serif'],
        doc: ['"Iowan Old Style"', '"Palatino Linotype"', 'Palatino', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
};

export default config;
