import { describe, expect, it } from "vitest";
import * as Y from "yjs";
import { authorizeClientMessage, MSG, SYNC } from "../shared/protocol";
import { resolveRole, canEdit, canComment, hasRole } from "../shared/rbac";
import { FRAGMENT, fragmentToPlainText, makeDocFromBlocks, restoreSnapshot, stateToHtml } from "../shared/yjs-utils";
import { MemoryBus, MemoryHub, MemoryStore } from "../ws-server/memory";
import { RoomManager } from "../ws-server/room";
import { YClient } from "./helpers/client";
import { connectFake, settle } from "./helpers/fake-socket";
import * as encoding from "lib0/encoding";
import * as syncProtocol from "y-protocols/sync";

/* ------------------------------- helpers ---------------------------------- */

function appendParagraph(doc: Y.Doc, text: string) {
  const frag = doc.getXmlFragment(FRAGMENT);
  const p = new Y.XmlElement("paragraph");
  const t = new Y.XmlText();
  t.insert(0, text);
  p.insert(0, [t]);
  frag.insert(frag.length, [p]);
}

function firstText(doc: Y.Doc): Y.XmlText {
  const p = doc.getXmlFragment(FRAGMENT).get(0) as Y.XmlElement;
  return p.get(0) as Y.XmlText;
}

const sameState = (a: Y.Doc, b: Y.Doc) =>
  Buffer.compare(Buffer.from(Y.encodeStateAsUpdate(a)), Buffer.from(Y.encodeStateAsUpdate(b))) === 0;

function makeManager(opts: Partial<ConstructorParameters<typeof RoomManager>[0]> = {}) {
  const store = (opts as any).store ?? new MemoryStore();
  const hub = (opts as any).hub ?? new MemoryHub();
  const manager = new RoomManager({
    instanceId: opts.instanceId ?? "ws-test-1",
    store,
    bus: new MemoryBus(hub),
    heartbeatMs: 0,
    saveIntervalMs: 50,
    ...opts,
  } as any);
  return { manager, store: store as MemoryStore, hub: hub as MemoryHub };
}

const alice = { id: "u-alice", name: "Alice" };
const bob = { id: "u-bob", name: "Bob" };
const carol = { id: "u-carol", name: "Carol" };

/* ------------------------ 1. offline merge convergence --------------------- */

describe("CRDT offline merge convergence", () => {
  it("merges concurrent offline edits identically in any delivery order", () => {
    const base = makeDocFromBlocks([{ type: "paragraph", text: "The quick fox" }]);
    const s = Y.encodeStateAsUpdate(base);
    const a = new Y.Doc();
    const b = new Y.Doc();
    Y.applyUpdate(a, s);
    Y.applyUpdate(b, s);

    // both users edit the SAME paragraph while offline
    firstText(a).insert(4, "very ");
    firstText(b).insert(13, " jumps");
    appendParagraph(b, "added by bob");

    const ua = Y.encodeStateAsUpdate(a);
    const ub = Y.encodeStateAsUpdate(b);

    const x = new Y.Doc();
    const y = new Y.Doc();
    Y.applyUpdate(x, s);
    Y.applyUpdate(y, s);
    Y.applyUpdate(x, ua);
    Y.applyUpdate(x, ub);
    Y.applyUpdate(y, ub);
    Y.applyUpdate(y, ua);

    expect(sameState(x, y)).toBe(true);
    expect(fragmentToPlainText(x)).toBe(fragmentToPlainText(y));
    expect(fragmentToPlainText(x)).toContain("The very quick fox jumps");
    expect(fragmentToPlainText(x)).toContain("added by bob");
  });

  it("two clients that go offline through the server converge after reconnecting", async () => {
    const { manager, store } = makeManager();
    const c1 = new YClient("c1");
    const c2 = new YClient("c2");
    const k1 = connectFake(manager, c1, "page-1", alice, "EDIT");
    const k2 = connectFake(manager, c2, "page-1", bob, "EDIT");
    await settle();

    appendParagraph(c1.doc, "shared start");
    await settle();
    expect(fragmentToPlainText(c2.doc)).toBe("shared start");

    // --- both lose connectivity and keep typing -------------------------------------
    k1.close();
    k2.close();
    await settle();
    firstText(c1.doc).insert(0, "[alice offline] ");
    firstText(c2.doc).insert(firstText(c2.doc).length, " [bob offline]");
    appendParagraph(c2.doc, "bob's second paragraph");
    expect(fragmentToPlainText(c1.doc)).not.toBe(fragmentToPlainText(c2.doc));

    // --- reconnect ---------------------------------------------------------------------
    k1.reconnect();
    k2.reconnect();
    await settle(120);

    const server = manager.getDoc("page-1")!;
    expect(sameState(c1.doc, c2.doc)).toBe(true);
    expect(sameState(c1.doc, server)).toBe(true);
    const text = fragmentToPlainText(c1.doc);
    expect(text).toContain("[alice offline]");
    expect(text).toContain("[bob offline]");
    expect(text).toContain("bob's second paragraph");

    k1.close();
    k2.close();
    await settle();
    expect(store.states.get("page-1")).toBeDefined();
  });
});

/* ------------------------------ 2. RBAC ------------------------------------ */

function syncMessage(kind: number, doc: Y.Doc) {
  const e = encoding.createEncoder();
  encoding.writeVarUint(e, MSG.SYNC);
  if (kind === SYNC.STEP1) syncProtocol.writeSyncStep1(e, doc);
  else if (kind === SYNC.STEP2) syncProtocol.writeSyncStep2(e, doc);
  else syncProtocol.writeUpdate(e, Y.encodeStateAsUpdate(doc));
  return encoding.toUint8Array(e);
}

describe("RBAC", () => {
  it("resolves effective roles (owner > creator > explicit page role > workspace default)", () => {
    expect(resolveRole({ isWorkspaceOwner: true, isPageCreator: false, pageRole: "VIEW" })).toEqual({ role: "EDIT", canManage: true });
    expect(resolveRole({ isWorkspaceOwner: false, isPageCreator: true })).toEqual({ role: "EDIT", canManage: true });
    expect(resolveRole({ isWorkspaceOwner: false, isPageCreator: false, membershipRole: "EDIT", pageRole: "VIEW" }).role).toBe("VIEW");
    expect(resolveRole({ isWorkspaceOwner: false, isPageCreator: false, membershipRole: "COMMENT" }).role).toBe("COMMENT");
    expect(resolveRole({ isWorkspaceOwner: false, isPageCreator: false, membershipRole: null }).role).toBeNull();
    expect(resolveRole({ isWorkspaceOwner: false, isPageCreator: false }).role).toBeNull();
    expect(hasRole("COMMENT", "VIEW")).toBe(true);
    expect(canEdit("COMMENT")).toBe(false);
    expect(canComment("VIEW")).toBe(false);
  });

  it("authorizeClientMessage allows reads but blocks mutations for VIEW/COMMENT", () => {
    const d = makeDocFromBlocks([{ type: "paragraph", text: "x" }]);
    for (const role of ["VIEW", "COMMENT"] as const) {
      expect(authorizeClientMessage(role, syncMessage(SYNC.STEP1, d)).ok).toBe(true);
      expect(authorizeClientMessage(role, syncMessage(SYNC.STEP2, d)).ok).toBe(false);
      expect(authorizeClientMessage(role, syncMessage(SYNC.UPDATE, d)).ok).toBe(false);
    }
    expect(authorizeClientMessage("EDIT", syncMessage(SYNC.UPDATE, d)).ok).toBe(true);
    expect(authorizeClientMessage("EDIT", syncMessage(SYNC.STEP2, d)).ok).toBe(true);
    expect(authorizeClientMessage("EDIT", new Uint8Array([99, 1, 2])).ok).toBe(false);
    expect(authorizeClientMessage("EDIT", new Uint8Array([])).ok).toBe(false);
  });

  it("the WebSocket server drops document mutations from VIEW and COMMENT users", async () => {
    const { manager } = makeManager();
    const editor = new YClient("editor");
    const viewer = new YClient("viewer");
    const commenter = new YClient("commenter");
    const ke = connectFake(manager, editor, "page-r", alice, "EDIT");
    const kv = connectFake(manager, viewer, "page-r", bob, "VIEW");
    const kc = connectFake(manager, commenter, "page-r", carol, "COMMENT");
    await settle();
    expect(viewer.role).toBe("VIEW");
    expect(commenter.role).toBe("COMMENT");

    appendParagraph(editor.doc, "legit content");
    await settle();
    // read access works
    expect(fragmentToPlainText(viewer.doc)).toBe("legit content");
    expect(fragmentToPlainText(commenter.doc)).toBe("legit content");

    // a tampered client tries to write anyway
    appendParagraph(viewer.doc, "VIEWER HACK");
    appendParagraph(commenter.doc, "COMMENTER HACK");
    await settle();

    const server = manager.getDoc("page-r")!;
    expect(fragmentToPlainText(server)).toBe("legit content");
    expect(fragmentToPlainText(editor.doc)).toBe("legit content");
    expect(viewer.denied.length).toBeGreaterThan(0);
    expect(commenter.denied.length).toBeGreaterThan(0);
    expect(manager.metrics.rejected).toBeGreaterThanOrEqual(2);

    // presence (awareness) is still allowed for read-only roles
    viewer.awareness.setLocalStateField("user", { name: "Bob", color: "#f00" });
    await settle();
    const seen = [...editor.awareness.getStates().values()].map((s: any) => s.user?.name);
    expect(seen).toContain("Bob");

    [ke, kv, kc].forEach((k) => k.close());
  });

  it("role changes take effect on live connections (promote / revoke)", async () => {
    const { manager } = makeManager();
    const c = new YClient("c");
    const k = connectFake(manager, c, "page-p", bob, "VIEW");
    await settle();
    await manager.refreshRoles("page-p", async () => "EDIT");
    await settle();
    expect(c.role).toBe("EDIT");
    appendParagraph(c.doc, "now allowed");
    await settle();
    expect(fragmentToPlainText(manager.getDoc("page-p")!)).toBe("now allowed");

    await manager.refreshRoles("page-p", async () => null); // revoked -> socket closed
    await settle();
    k.close();
  });
});

/* ------------------------ 3. snapshot restoration -------------------------- */

describe("snapshot restoration", () => {
  it("restores a past state as a new transaction and keeps history", () => {
    const doc = makeDocFromBlocks([
      { type: "heading", level: 1, text: "Plan" },
      { type: "paragraph", text: "version one" },
    ]);
    const snapshot = Y.encodeStateAsUpdate(doc);
    const textV1 = fragmentToPlainText(doc);

    appendParagraph(doc, "later addition");
    (doc.getXmlFragment(FRAGMENT).get(1) as Y.XmlElement).delete(0, 1);
    expect(fragmentToPlainText(doc)).not.toBe(textV1);

    restoreSnapshot(doc, snapshot);
    expect(fragmentToPlainText(doc)).toBe(textV1);

    // idempotent: restoring twice must not duplicate content
    restoreSnapshot(doc, snapshot);
    expect(fragmentToPlainText(doc)).toBe(textV1);

    // editing continues to work after restore
    appendParagraph(doc, "after restore");
    expect(fragmentToPlainText(doc)).toBe(textV1 + "\nafter restore");
    expect(stateToHtml(snapshot)).toContain("<h1>Plan</h1>");
  });

  it("restore on the live server converges every client and persists", async () => {
    const { manager, store } = makeManager();
    const a = new YClient("a");
    const b = new YClient("b");
    const ka = connectFake(manager, a, "page-s", alice, "EDIT");
    const kb = connectFake(manager, b, "page-s", bob, "VIEW");
    await settle();

    appendParagraph(a.doc, "keep me");
    await settle();
    const snapshot = Y.encodeStateAsUpdate(manager.getDoc("page-s")!);

    appendParagraph(a.doc, "regret this");
    await settle();
    expect(fragmentToPlainText(b.doc)).toContain("regret this");

    expect(await manager.restore("page-s", snapshot)).toBe(true);
    await settle();
    expect(fragmentToPlainText(a.doc)).toBe("keep me");
    expect(fragmentToPlainText(b.doc)).toBe("keep me");
    expect(sameState(a.doc, manager.getDoc("page-s")!)).toBe(true);

    const persisted = new Y.Doc();
    Y.applyUpdate(persisted, store.states.get("page-s")!);
    expect(fragmentToPlainText(persisted)).toBe("keep me");
    expect(await manager.restore("missing-room", snapshot)).toBe(false);
    ka.close();
    kb.close();
  });
});

/* ----------------- 4. persistence (rehydrate / debounce / flush) ------------- */

describe("persistence", () => {
  it("debounces saves, flushes + snapshots on last disconnect, and rehydrates", async () => {
    const store = new MemoryStore();
    const { manager } = makeManager({ store, saveIntervalMs: 100 } as any);
    const a = new YClient("a");
    const k = connectFake(manager, a, "page-d", alice, "EDIT");
    await settle();

    for (let i = 0; i < 20; i++) appendParagraph(a.doc, `line ${i}`);
    await settle(30);
    expect(store.saves).toBe(0); // still inside the debounce window
    await settle(200);
    expect(store.saves).toBe(1); // 20 edits -> one write

    appendParagraph(a.doc, "last words");
    k.close(); // last user disconnects -> immediate flush, no waiting for the timer
    await settle(30);
    expect(store.saves).toBe(2);
    expect(store.snapshots.length).toBe(1);
    expect(manager.stats().rooms).toBe(0);

    // a new server instance rehydrates from the persisted bytes when the first user joins
    const { manager: m2 } = makeManager({ store, instanceId: "ws-test-2" } as any);
    const b = new YClient("b");
    const kb = connectFake(m2, b, "page-d", bob, "VIEW");
    await settle();
    expect(fragmentToPlainText(b.doc)).toContain("last words");
    expect(fragmentToPlainText(b.doc).split("\n")).toHaveLength(21);
    kb.close();
  });
});

/* ----------------------- 5. Redis multi-instance sync ----------------------- */

describe("multi-instance sync over the pub/sub bus", () => {
  it("clients on different server instances collaborate in real time", async () => {
    const hub = new MemoryHub();
    const store = new MemoryStore();
    const { manager: m1 } = makeManager({ hub, store, instanceId: "ws-4001" } as any);
    const { manager: m2 } = makeManager({ hub, store, instanceId: "ws-4002" } as any);
    const a = new YClient("a");
    const b = new YClient("b");
    a.awareness.setLocalStateField("user", { name: "Alice" });
    b.awareness.setLocalStateField("user", { name: "Bob" });
    const ka = connectFake(m1, a, "page-x", alice, "EDIT");
    const kb = connectFake(m2, b, "page-x", bob, "EDIT");
    await settle(80);

    appendParagraph(a.doc, "from 4001");
    appendParagraph(b.doc, "from 4002");
    await settle(80);
    expect(sameState(a.doc, b.doc)).toBe(true);
    expect(fragmentToPlainText(a.doc)).toContain("from 4001");
    expect(fragmentToPlainText(a.doc)).toContain("from 4002");
    expect(sameState(m1.getDoc("page-x")!, m2.getDoc("page-x")!)).toBe(true);

    // presence crosses instances
    const namesSeenByA = [...a.awareness.getStates().values()].map((s: any) => s.user?.name).sort();
    expect(namesSeenByA).toEqual(["Alice", "Bob"]);

    // a user disconnecting on one instance disappears from the other
    kb.close();
    await settle(80);
    const after = [...a.awareness.getStates().values()].map((s: any) => s.user?.name);
    expect(after).toEqual(["Alice"]);
    ka.close();
  });

  it("a late joiner on another instance gets edits that were not persisted yet", async () => {
    const hub = new MemoryHub();
    const store = new MemoryStore();
    const { manager: m1 } = makeManager({ hub, store, instanceId: "i1", saveIntervalMs: 60_000 } as any);
    const { manager: m2 } = makeManager({ hub, store, instanceId: "i2", saveIntervalMs: 60_000 } as any);
    const a = new YClient("a");
    const ka = connectFake(m1, a, "page-y", alice, "EDIT");
    await settle();
    appendParagraph(a.doc, "unsaved edit");
    await settle();
    expect(store.states.get("page-y")).toBeUndefined(); // DB knows nothing yet

    const c = new YClient("c");
    const kc = connectFake(m2, c, "page-y", carol, "VIEW");
    await settle(100);
    expect(fragmentToPlainText(c.doc)).toBe("unsaved edit"); // delivered via SYNC_REQUEST over the bus
    ka.close();
    kc.close();
  });
});
