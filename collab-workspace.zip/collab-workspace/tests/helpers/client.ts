import * as Y from "yjs";
import * as syncProtocol from "y-protocols/sync";
import * as awarenessProtocol from "y-protocols/awareness";
import * as encoding from "lib0/encoding";
import * as decoding from "lib0/decoding";
import { MSG, SYNC } from "../../shared/protocol";
import { Role } from "../../shared/rbac";

/**
 * Minimal protocol-compatible Yjs client (same wire protocol as the browser provider).
 * Transport-agnostic: the caller wires `online(send)` / `receive(data)` to a real or fake socket.
 */
export class YClient {
  doc = new Y.Doc();
  awareness = new awarenessProtocol.Awareness(this.doc);
  role: Role | null = null;
  denied: string[] = [];
  synced = false;
  private out: ((d: Uint8Array) => void) | null = null;

  constructor(public name: string) {
    this.doc.on("update", (u: Uint8Array, origin: unknown) => {
      if (origin === this || !this.out) return;
      const e = encoding.createEncoder();
      encoding.writeVarUint(e, MSG.SYNC);
      syncProtocol.writeUpdate(e, u);
      this.out(encoding.toUint8Array(e));
    });
    this.awareness.on("update", ({ added, updated, removed }: any, origin: unknown) => {
      if (origin !== "local" || !this.out) return;
      const e = encoding.createEncoder();
      encoding.writeVarUint(e, MSG.AWARENESS);
      encoding.writeVarUint8Array(
        e,
        awarenessProtocol.encodeAwarenessUpdate(this.awareness, added.concat(updated, removed))
      );
      this.out(encoding.toUint8Array(e));
    });
  }

  /** Go online: send sync step 1 (+ our awareness). Offline edits are exchanged by the sync. */
  online(send: (d: Uint8Array) => void) {
    this.out = send;
    this.synced = false;
    const e = encoding.createEncoder();
    encoding.writeVarUint(e, MSG.SYNC);
    syncProtocol.writeSyncStep1(e, this.doc);
    send(encoding.toUint8Array(e));
    if (this.awareness.getLocalState()) {
      const a = encoding.createEncoder();
      encoding.writeVarUint(a, MSG.AWARENESS);
      encoding.writeVarUint8Array(a, awarenessProtocol.encodeAwarenessUpdate(this.awareness, [this.doc.clientID]));
      send(encoding.toUint8Array(a));
    }
  }

  offline() {
    this.out = null;
  }

  receive(data: Uint8Array) {
    const dec = decoding.createDecoder(data);
    const type = decoding.readVarUint(dec);
    if (type === MSG.SYNC) {
      const enc = encoding.createEncoder();
      encoding.writeVarUint(enc, MSG.SYNC);
      const t = syncProtocol.readSyncMessage(dec, enc, this.doc, this);
      if (t === SYNC.STEP2) this.synced = true;
      if (encoding.length(enc) > 1) this.out?.(encoding.toUint8Array(enc));
    } else if (type === MSG.AWARENESS) {
      awarenessProtocol.applyAwarenessUpdate(this.awareness, decoding.readVarUint8Array(dec), this);
    } else if (type === MSG.AUTH) {
      this.role = JSON.parse(decoding.readVarString(dec)).role;
    } else if (type === MSG.DENIED) {
      this.denied.push(decoding.readVarString(dec));
    }
  }

  destroy() {
    awarenessProtocol.removeAwarenessStates(this.awareness, [this.doc.clientID], "local");
    this.awareness.destroy();
    this.doc.destroy();
  }
}
