import { RoomManager, SocketLike } from "../../ws-server/room";
import { Role } from "../../shared/rbac";
import { YClient } from "./client";

export interface FakeConnection {
  ready: Promise<void>;
  close(): void;
  reconnect(): void;
}

/** Connect a YClient to a RoomManager through an in-process fake WebSocket. */
export function connectFake(
  manager: RoomManager,
  client: YClient,
  pageId: string,
  user: { id: string; name: string },
  role: Role
): FakeConnection {
  let handlers: Record<string, Array<(...a: any[]) => void>> = {};
  const emit = (ev: string, ...a: any[]) => handlers[ev]?.forEach((f) => f(...a));
  let socket: SocketLike;
  let ready: Promise<void>;

  const open = () => {
    handlers = {};
    socket = {
      readyState: 1,
      send(data) {
        const copy = new Uint8Array(data);
        queueMicrotask(() => client.receive(copy));
      },
      close() {
        if (socket.readyState === 3) return;
        socket.readyState = 3;
        queueMicrotask(() => emit("close"));
      },
      on(ev, fn) {
        (handlers[ev] ||= []).push(fn);
      },
    };
    ready = manager.connect(socket, pageId, user, role);
    client.online((d) => {
      const copy = new Uint8Array(d);
      queueMicrotask(() => emit("message", copy));
    });
  };
  open();

  return {
    get ready() {
      return ready;
    },
    close() {
      client.offline();
      socket.readyState = 3;
      emit("close");
    },
    reconnect() {
      open();
    },
  } as FakeConnection;
}

export const settle = (ms = 40) => new Promise((r) => setTimeout(r, ms));
