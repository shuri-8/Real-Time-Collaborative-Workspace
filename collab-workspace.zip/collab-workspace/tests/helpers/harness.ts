import http from "node:http";
import { WebSocketServer } from "ws";
import { MemoryBus, MemoryHub, MemoryStore } from "../../ws-server/memory";
import { RoomManager, SocketLike } from "../../ws-server/room";

/**
 * Self-contained stand-in for `ws-server/server.ts` (no PostgreSQL, Redis or auth):
 * N WebSocket servers backed by the REAL RoomManager, connected through an in-process pub/sub hub.
 * Lets `npm run load -- --harness` run anywhere.
 */
export async function startHarness(ports: number[]) {
  const hub = new MemoryHub();
  const store = new MemoryStore();
  const servers: Array<{ manager: RoomManager; http: http.Server; wss: WebSocketServer }> = [];
  let n = 0;
  for (const port of ports) {
    const manager = new RoomManager({ instanceId: `harness-${port}`, store, bus: new MemoryBus(hub), heartbeatMs: 0 });
    const srv = http.createServer((req, res) => {
      if (req.url === "/health") {
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify(manager.stats()));
      } else res.writeHead(426).end();
    });
    const wss = new WebSocketServer({ server: srv, perMessageDeflate: false });
    wss.on("connection", (ws, req) => {
      const pageId = decodeURIComponent((req.url ?? "/").split("?")[0].slice(1));
      void manager.connect(ws as unknown as SocketLike, pageId, { id: `u${n++}`, name: "load" }, "EDIT");
    });
    await new Promise<void>((r) => srv.listen(port, r));
    servers.push({ manager, http: srv, wss });
  }
  return {
    store,
    managers: servers.map((s) => s.manager),
    async stop() {
      for (const s of servers) {
        await s.manager.shutdown();
        s.wss.close();
        s.http.close();
      }
    },
  };
}
