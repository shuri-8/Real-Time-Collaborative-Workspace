/**
 * Load test: N concurrent WebSocket clients editing ONE document simultaneously, spread across
 * several WebSocket server instances (4001 + 4002) that are linked only through Redis Pub/Sub.
 *
 *   npm run load                      # against the docker-compose stack (needs seed data)
 *   npm run load -- --harness         # self-contained: in-process servers, no DB/Redis
 *   npm run load -- --clients=50 --duration=20 --rate=2 --gutenberg
 *
 * Reports p50/p95/p99 propagation latency, throughput, memory usage and verifies that every
 * client (plus a fresh verifier) converged to the identical document.
 */
import "dotenv/config";
import { writeFileSync } from "node:fs";
import * as Y from "yjs";
import WebSocket from "ws";
import { signToken } from "../shared/auth-token";
import { FRAGMENT, fragmentToPlainText } from "../shared/yjs-utils";
import { YClient } from "./helpers/client";

/* ------------------------------- configuration ------------------------------ */

const arg = (name: string, def?: string) => {
  const hit = process.argv.find((a) => a === `--${name}` || a.startsWith(`--${name}=`));
  if (!hit) return def;
  return hit.includes("=") ? hit.split("=")[1] : "true";
};
const CLIENTS = Number(arg("clients", "50"));
const DURATION_S = Number(arg("duration", "20"));
const RATE = Number(arg("rate", "2")); // edits per second per client
const PORTS = (arg("ports", "4001,4002") as string).split(",").map(Number);
const HOST = arg("host", "localhost") as string;
const PAGE_ID = arg("page", "demo-page-loadtest") as string;
const HARNESS = arg("harness") === "true";
const USE_GUTENBERG = arg("gutenberg") === "true";

/* ------------------------------- sample text -------------------------------- */
// Public-domain passages (Project Gutenberg: Austen, Dickens, Melville, Carroll).
const EMBEDDED = `It is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife.
However little known the feelings or views of such a man may be on his first entering a neighbourhood, this truth is so well fixed in the minds of the surrounding families, that he is considered the rightful property of some one or other of their daughters.
It was the best of times, it was the worst of times, it was the age of wisdom, it was the age of foolishness.
It was the epoch of belief, it was the epoch of incredulity, it was the season of Light, it was the season of Darkness.
Call me Ishmael. Some years ago, never mind how long precisely, having little or no money in my purse, and nothing particular to interest me on shore, I thought I would sail about a little and see the watery part of the world.
Whenever I find myself growing grim about the mouth, whenever it is a damp, drizzly November in my soul, I account it high time to get to sea as soon as I can.
Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do.
Once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it.
So she was considering in her own mind whether the pleasure of making a daisy-chain would be worth the trouble of getting up and picking the daisies.
Suddenly a White Rabbit with pink eyes ran close by her.
There was nothing so very remarkable in that, nor did Alice think it so very much out of the way to hear the Rabbit say to itself, Oh dear! Oh dear! I shall be late!
Happy families are all alike; every unhappy family is unhappy in its own way.
There is no charm equal to tenderness of heart.
I declare after all there is no enjoyment like reading!
The whale, the whale! Thar she blows! A hump like a snow-hill!`;

async function loadSentences(): Promise<string[]> {
  let text = EMBEDDED;
  if (USE_GUTENBERG) {
    try {
      const r = await fetch("https://www.gutenberg.org/cache/epub/1342/pg1342.txt", { signal: AbortSignal.timeout(8000) });
      const full = await r.text();
      const start = full.indexOf("It is a truth universally acknowledged");
      text = full.slice(start, start + 60_000);
      console.log("Using Project Gutenberg text (Pride and Prejudice).");
    } catch {
      console.log("Gutenberg fetch failed; using embedded public-domain excerpts.");
    }
  }
  const s = text.replace(/\s+/g, " ").match(/[^.!?]+[.!?]+/g) ?? [text];
  return s.map((x) => x.trim()).filter((x) => x.length > 20);
}

/* ---------------------------------- helpers --------------------------------- */

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const pct = (sorted: number[], p: number) => (sorted.length ? sorted[Math.min(sorted.length - 1, Math.ceil((p / 100) * sorted.length) - 1)] : NaN);
const mb = (n: number) => Math.round((n / 1048576) * 10) / 10;
const hex = (u: Uint8Array) => Buffer.from(u).toString("hex");

interface LoadClient {
  idx: number;
  port: number;
  y: YClient;
  ws: WebSocket;
  sent: number;
  received: number;
}

function openClient(idx: number, port: number, headers: Record<string, string>, latencies: number[]): Promise<LoadClient> {
  return new Promise((resolve, reject) => {
    const y = new YClient(`load-${idx}`);
    const ws = new WebSocket(`ws://${HOST}:${port}/${PAGE_ID}`, { headers, perMessageDeflate: false });
    ws.binaryType = "nodebuffer";
    const c: LoadClient = { idx, port, y, ws, sent: 0, received: 0 };
    y.awareness.setLocalStateField("user", { name: `Load ${idx}`, color: "#0b6e5f" });

    // latency = (time the paragraph became visible here) - (time its author created it)
    y.doc.getXmlFragment(FRAGMENT).observeDeep((events, tr) => {
      if (tr.origin !== y) return;
      for (const ev of events) {
        for (const item of ev.changes.added) {
          for (const content of item.content.getContent()) {
            if (!(content instanceof Y.XmlElement)) continue;
            const m = /^L\|(\d+)\|(\d+)\|(\d+)\|/.exec(content.toString().replace(/<[^>]+>/g, ""));
            if (!m || Number(m[1]) === idx) continue;
            c.received++;
            latencies.push(Date.now() - Number(m[3]));
          }
        }
      }
    });

    ws.on("open", () => y.online((d) => ws.readyState === WebSocket.OPEN && ws.send(d)));
    ws.on("message", (data: Buffer) => {
      y.receive(new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
      if (y.synced && y.role) resolve(c);
    });
    ws.on("error", reject);
    ws.on("unexpected-response", (_req, res) => reject(new Error(`HTTP ${res.statusCode} from :${port} (is the page seeded and are you logged in as a member?)`)));
    setTimeout(() => reject(new Error(`client ${idx} timed out connecting to :${port}`)), 15000);
  });
}

function typeSentence(c: LoadClient, sentences: string[]) {
  const doc = c.y.doc;
  const p = new Y.XmlElement("paragraph");
  const t = new Y.XmlText();
  const sentence = sentences[(c.idx * 7 + c.sent) % sentences.length];
  t.insert(0, `L|${c.idx}|${c.sent}|${Date.now()}| ${sentence}`);
  p.insert(0, [t]);
  const frag = doc.getXmlFragment(FRAGMENT);
  frag.insert(frag.length, [p]); // concurrent appends at the same index -> the CRDT must interleave deterministically
  c.sent++;
}

async function fetchHealth(port: number) {
  try {
    const r = await fetch(`http://${HOST}:${port}/health`, { signal: AbortSignal.timeout(3000) });
    return await r.json();
  } catch {
    return null;
  }
}

/* ----------------------------------- main ----------------------------------- */

async function main() {
  console.log(`\nLoad test: ${CLIENTS} clients × ${RATE} edits/s for ${DURATION_S}s  →  ports ${PORTS.join(", ")} ${HARNESS ? "(in-process harness)" : ""}\n`);
  const sentences = await loadSentences();

  let harness: Awaited<ReturnType<typeof import("./helpers/harness").startHarness>> | null = null;
  let headers: Record<string, string> = {};
  if (HARNESS) {
    const { startHarness } = await import("./helpers/harness");
    harness = await startHarness(PORTS);
  } else {
    const token = await signToken({ sub: "user-alice", name: "Alice" });
    headers = { Cookie: `cw_token=${token}` };
  }

  const latencies: number[] = [];
  const baseMem = process.memoryUsage();
  const clients: LoadClient[] = [];
  const t0 = Date.now();
  for (let i = 0; i < CLIENTS; i += 10) {
    const batch = await Promise.all(
      Array.from({ length: Math.min(10, CLIENTS - i) }, (_, k) => openClient(i + k, PORTS[(i + k) % PORTS.length], headers, latencies))
    );
    clients.push(...batch);
  }
  console.log(`Connected ${clients.length} clients in ${Date.now() - t0} ms (${PORTS.map((p) => `${clients.filter((c) => c.port === p).length}→:${p}`).join("  ")})`);
  await sleep(500);
  latencies.length = 0; // ignore handshake noise

  // ---- edit phase ------------------------------------------------------------------
  const start = Date.now();
  let running = true;
  const loops = clients.map(async (c) => {
    await sleep(Math.random() * (1000 / RATE));
    while (running) {
      typeSentence(c, sentences);
      await sleep((1000 / RATE) * (0.5 + Math.random()));
    }
  });
  let peakRss = 0;
  const memTimer = setInterval(() => (peakRss = Math.max(peakRss, process.memoryUsage().rss)), 250);
  await sleep(DURATION_S * 1000);
  running = false;
  await Promise.all(loops);
  const editMs = Date.now() - start;

  // ---- convergence -----------------------------------------------------------------
  const totalSent = clients.reduce((a, c) => a + c.sent, 0);
  const verifierSock = await openClient(9999, PORTS[0], headers, []);
  const everyone = [...clients, verifierSock];
  const deadline = Date.now() + 30_000;
  let converged = false;
  while (Date.now() < deadline) {
    const vectors = new Set(everyone.map((c) => hex(Y.encodeStateVector(c.y.doc))));
    const counts = everyone.map((c) => c.y.doc.getXmlFragment(FRAGMENT).length);
    if (vectors.size === 1 && counts.every((n) => n === counts[0])) {
      converged = true;
      break;
    }
    await sleep(250);
  }
  clearInterval(memTimer);
  const refText = fragmentToPlainText(verifierSock.y.doc);
  const identicalText = everyone.every((c) => fragmentToPlainText(c.y.doc) === refText);
  const markers = new Set((refText.match(/^L\|(\d+)\|(\d+)\|/gm) ?? []));
  const allEditsPresent = markers.size === totalSent;
  const identicalState = new Set(everyone.map((c) => hex(Y.encodeStateVector(c.y.doc)))).size === 1;

  // ---- report ----------------------------------------------------------------------
  const sorted = [...latencies].sort((a, b) => a - b);
  const health = HARNESS ? harness!.managers.map((m) => m.stats()) : await Promise.all(PORTS.map(fetchHealth));
  const mem = process.memoryUsage();
  const result = {
    config: { clients: CLIENTS, durationSeconds: DURATION_S, editsPerSecondPerClient: RATE, ports: PORTS, harness: HARNESS },
    edits: { sent: totalSent, throughputEditsPerSec: Math.round((totalSent / editMs) * 1000 * 10) / 10 },
    deliveries: { samples: sorted.length, throughputPerSec: Math.round((sorted.length / editMs) * 1000) },
    latencyMs: { p50: pct(sorted, 50), p95: pct(sorted, 95), p99: pct(sorted, 99), max: sorted[sorted.length - 1] ?? NaN, mean: Math.round((sorted.reduce((a, b) => a + b, 0) / (sorted.length || 1)) * 10) / 10 },
    memoryMb: { loadTestRssBefore: mb(baseMem.rss), loadTestRssPeak: mb(peakRss), loadTestHeapUsed: mb(mem.heapUsed), servers: health.map((h: any) => (h ? { instance: h.instanceId, rssMb: h.rssMb, heapUsedMb: h.heapUsedMb, connections: h.connections } : null)) },
    convergence: { converged, identicalStateVectors: identicalState, identicalText, expectedParagraphs: totalSent, paragraphsFound: markers.size, allEditsPresent, finalBlocks: verifierSock.y.doc.getXmlFragment(FRAGMENT).length },
  };

  console.log("\n================ RESULTS ================");
  console.log(`Edits sent            : ${result.edits.sent}  (${result.edits.throughputEditsPerSec} edits/s)`);
  console.log(`Deliveries measured   : ${result.deliveries.samples}  (${result.deliveries.throughputPerSec} deliveries/s)`);
  console.log(`Latency  p50 / p95 / p99 : ${result.latencyMs.p50} / ${result.latencyMs.p95} / ${result.latencyMs.p99} ms   (max ${result.latencyMs.max} ms, mean ${result.latencyMs.mean} ms)`);
  console.log(`Memory (load test)    : rss ${result.memoryMb.loadTestRssBefore} → peak ${result.memoryMb.loadTestRssPeak} MB, heap ${result.memoryMb.loadTestHeapUsed} MB`);
  for (const s of result.memoryMb.servers) console.log(`Memory (server)       : ${s ? `${s.instance}: rss ${s.rssMb} MB, heap ${s.heapUsedMb} MB, ${s.connections} conns` : "health endpoint unreachable"}`);
  console.log(`Convergence           : ${converged ? "PASS" : "FAIL"}  (state vectors identical: ${identicalState}, text identical: ${identicalText}, edits present: ${markers.size}/${totalSent})`);
  console.log("=========================================\n");

  writeFileSync("tests/load-test-results.json", JSON.stringify(result, null, 2));
  console.log("Wrote tests/load-test-results.json");

  clients.forEach((c) => c.ws.close());
  verifierSock.ws.close();
  await sleep(300);
  if (harness) await harness.stop();
  process.exit(converged && identicalText && allEditsPresent ? 0 : 1);
}

main().catch((e) => {
  console.error("Load test failed:", e.message);
  process.exit(1);
});
