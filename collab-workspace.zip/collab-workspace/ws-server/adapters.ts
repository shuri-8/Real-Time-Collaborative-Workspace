import { PrismaClient } from "@prisma/client";
import Redis from "ioredis";
import { Bus, Store } from "./room";

/** PostgreSQL persistence through Prisma (`Page.ydocState` + `PageVersion`). */
export class PrismaStore implements Store {
  constructor(private prisma: PrismaClient) {}

  async load(pageId: string): Promise<Uint8Array | null> {
    const page = await this.prisma.page.findUnique({ where: { id: pageId }, select: { ydocState: true } });
    return page?.ydocState ? new Uint8Array(page.ydocState) : null;
  }

  async save(pageId: string, state: Uint8Array): Promise<void> {
    await this.prisma.page.update({ where: { id: pageId }, data: { ydocState: Buffer.from(state) } });
  }

  async snapshot(pageId: string, state: Uint8Array): Promise<void> {
    // Two instances may close the same room around the same time: skip identical snapshots.
    const last = await this.prisma.pageVersion.findFirst({
      where: { pageId },
      orderBy: { createdAt: "desc" },
      select: { state: true, createdAt: true },
    });
    if (last && Buffer.compare(Buffer.from(last.state), Buffer.from(state)) === 0) return;
    if (last && Date.now() - last.createdAt.getTime() < 3000) return;
    await this.prisma.pageVersion.create({
      data: { pageId, state: Buffer.from(state), kind: "AUTO", label: "Auto-saved" },
    });
  }
}

/** Redis Pub/Sub bus: one publisher connection and one subscriber connection per process. */
export class RedisBus implements Bus {
  private pub: Redis;
  private sub: Redis;
  private handlers = new Map<string, (d: Uint8Array) => void>();

  constructor(url: string) {
    this.pub = new Redis(url, { maxRetriesPerRequest: null });
    this.sub = new Redis(url, { maxRetriesPerRequest: null });
    this.sub.on("messageBuffer", (channel: Buffer, message: Buffer) => {
      this.handlers.get(channel.toString())?.(new Uint8Array(message));
    });
  }

  publish(channel: string, data: Uint8Array): void {
    void this.pub.publish(channel, Buffer.from(data)).catch(() => {});
  }
  async subscribe(channel: string, handler: (d: Uint8Array) => void): Promise<void> {
    this.handlers.set(channel, handler);
    await this.sub.subscribe(channel);
  }
  async unsubscribe(channel: string): Promise<void> {
    this.handlers.delete(channel);
    await this.sub.unsubscribe(channel);
  }
  get publisher() {
    return this.pub;
  }
  get subscriber() {
    return this.sub;
  }
  async close() {
    this.pub.disconnect();
    this.sub.disconnect();
  }
}
