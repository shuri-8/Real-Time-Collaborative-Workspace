import { Bus, Store } from "./room";

/** In-memory Store: used by unit tests and by the self-contained load-test harness. */
export class MemoryStore implements Store {
  states = new Map<string, Uint8Array>();
  snapshots: Array<{ pageId: string; state: Uint8Array }> = [];
  saves = 0;
  async load(pageId: string) {
    return this.states.get(pageId) ?? null;
  }
  async save(pageId: string, state: Uint8Array) {
    this.states.set(pageId, state);
    this.saves++;
  }
  async snapshot(pageId: string, state: Uint8Array) {
    this.snapshots.push({ pageId, state });
  }
}

/** In-process stand-in for Redis Pub/Sub shared by several RoomManagers. */
export class MemoryHub {
  private subs = new Map<string, Set<MemoryBus>>();
  join(channel: string, bus: MemoryBus) {
    if (!this.subs.has(channel)) this.subs.set(channel, new Set());
    this.subs.get(channel)!.add(bus);
  }
  leave(channel: string, bus: MemoryBus) {
    this.subs.get(channel)?.delete(bus);
  }
  publish(channel: string, data: Uint8Array) {
    for (const b of this.subs.get(channel) ?? []) queueMicrotask(() => b.deliver(channel, data));
  }
}

export class MemoryBus implements Bus {
  private handlers = new Map<string, (d: Uint8Array) => void>();
  constructor(private hub: MemoryHub) {}
  publish(channel: string, data: Uint8Array) {
    this.hub.publish(channel, data);
  }
  async subscribe(channel: string, handler: (d: Uint8Array) => void) {
    this.handlers.set(channel, handler);
    this.hub.join(channel, this);
  }
  async unsubscribe(channel: string) {
    this.handlers.delete(channel);
    this.hub.leave(channel, this);
  }
  deliver(channel: string, data: Uint8Array) {
    this.handlers.get(channel)?.(data);
  }
}
