import * as Y from "yjs";
import * as syncProtocol from "y-protocols/sync";
import * as awarenessProtocol from "y-protocols/awareness";
import * as encoding from "lib0/encoding";
import * as decoding from "lib0/decoding";
import {
  BUS,
  MSG,
  authorizeClientMessage,
  decodeBus,
  docChannel,
  encodeAuth,
  encodeBus,
  encodeDenied,
  isDocMutation,
  inspectMessage,
} from "../shared/protocol";
import { Role } from "../shared/rbac";
import { restoreSnapshot } from "../shared/yjs-utils";

/* ----------------------------- adapters (ports) ---------------------------- */

export interface Store {
  load(pageId: string): Promise<Uint8Array | null>;
  save(pageId: string, state: Uint8Array): Promise<void>;
  snapshot(pageId: string, state: Uint8Array): Promise<void>;
}

export interface Bus {
  publish(channel: string, data: Uint8Array): void;
  subscribe(channel: string, handler: (data: Uint8Array) => void): Promise<void>;
  unsubscribe(channel: string): Promise<void>;
}

/** The subset of the `ws` WebSocket API the manager needs (lets tests use fake sockets). */
export interface SocketLike {
  readyState: number;
  send(data: Uint8Array, cb?: (err?: Error) => void): void;
  close(code?: number, reason?: string): void;
  on(event: string, listener: (...args: any[]) => void): unknown;
  ping?(): void;
  terminate?(): void;
}

export interface ManagerOptions {
  instanceId: string;
  store: Store;
  bus: Bus;
  /** Persist at most this often while a room is dirty (default 2000 ms). */
  saveIntervalMs?: number;
  /** Take an automatic version snapshot at most this often per room (default 5 min). */
  autoSnapshotMs?: number;
  heartbeatMs?: number;
  onRoomOpen?: (pageId: string) => void;
  onRoomClose?: (pageId: string) => void;
  log?: (msg: string, extra?: unknown) => void;
}

/* --------------------------------- types ---------------------------------- */

export interface ConnUser {
  id: string;
  name: string;
}

class Conn {
  controlledIds = new Set<number>();
  alive = true;
  constructor(public user: ConnUser, public role: Role) {}
}

class Room {
  conns = new Map<SocketLike, Conn>();
  dirty = false;
  changedSinceSnapshot = false;
  lastSnapshotAt = Date.now();
  closing = false;
  saveTimer: NodeJS.Timeout | null = null;
  saveChain: Promise<void> = Promise.resolve();
  constructor(public pageId: string, public doc: Y.Doc, public awareness: awarenessProtocol.Awareness) {}
}

const OPEN = 1;

function toU8(raw: any): Uint8Array {
  if (raw instanceof Uint8Array) return raw;
  if (raw instanceof ArrayBuffer) return new Uint8Array(raw);
  if (Array.isArray(raw)) return new Uint8Array(Buffer.concat(raw));
  return new Uint8Array(raw);
}

/* -------------------------------- manager ---------------------------------- */

export class RoomManager {
  private pending = new Map<string, Promise<Room>>();
  private ready = new Map<string, Room>();
  private heartbeat?: NodeJS.Timeout;
  readonly metrics = { messagesIn: 0, rejected: 0, updatesFromBus: 0, saves: 0, snapshots: 0 };
  private saveMs: number;
  private snapMs: number;
  private log: (msg: string, extra?: unknown) => void;

  constructor(private opts: ManagerOptions) {
    this.saveMs = opts.saveIntervalMs ?? 2000;
    this.snapMs = opts.autoSnapshotMs ?? 5 * 60_000;
    this.log = opts.log ?? (() => {});
    const hb = opts.heartbeatMs ?? 30_000;
    if (hb > 0) {
      this.heartbeat = setInterval(() => this.beat(), hb);
      this.heartbeat.unref();
    }
  }

  get id() {
    return this.opts.instanceId;
  }

  /* ------------------------------ room lifecycle ----------------------------- */

  private getRoom(pageId: string): Promise<Room> {
    let p = this.pending.get(pageId);
    if (!p) {
      p = this.createRoom(pageId).catch((e) => {
        this.pending.delete(pageId);
        throw e;
      });
      this.pending.set(pageId, p);
    }
    return p;
  }

  private async createRoom(pageId: string): Promise<Room> {
    const doc = new Y.Doc();
    const awareness = new awarenessProtocol.Awareness(doc);
    awareness.setLocalState(null); // the server itself is not a participant
    const room = new Room(pageId, doc, awareness);

    // Rehydrate Y.Doc from PostgreSQL bytes when the first user joins.
    const state = await this.opts.store.load(pageId);
    if (state && state.length) Y.applyUpdate(doc, state, "db");

    doc.on("update", (update: Uint8Array, origin: unknown) => this.onDocUpdate(room, update, origin));
    awareness.on(
      "update",
      (
        ch: { added: number[]; updated: number[]; removed: number[] },
        origin: unknown
      ) => this.onAwarenessUpdate(room, ch, origin)
    );

    // Redis Pub/Sub: join the room channel, then ask peers for anything we are missing.
    await this.opts.bus.subscribe(docChannel(pageId), (data) => this.onBus(room, data));
    this.publish(room, BUS.SYNC_REQUEST, Y.encodeStateVector(doc));
    this.publish(room, BUS.AWARENESS_QUERY, new Uint8Array(0));

    this.ready.set(pageId, room);
    this.opts.onRoomOpen?.(pageId);
    this.log(`room open ${pageId}`);
    return room;
  }

  private async maybeClose(room: Room) {
    if (room.conns.size > 0 || room.closing) return;
    room.closing = true;
    await this.flush(room, { snapshot: true }); // last user left: persist immediately
    if (room.conns.size > 0) {
      room.closing = false;
      return;
    }
    this.pending.delete(room.pageId);
    this.ready.delete(room.pageId);
    await this.opts.bus.unsubscribe(docChannel(room.pageId));
    awarenessProtocol.removeAwarenessStates(room.awareness, [...room.awareness.getStates().keys()], "close");
    room.awareness.destroy();
    room.doc.destroy();
    this.opts.onRoomClose?.(room.pageId);
    this.log(`room closed ${room.pageId}`);
  }

  /* -------------------------------- connections ------------------------------ */

  /**
   * Attach an authenticated socket to a room. Call synchronously from the upgrade callback so
   * no message is lost while the room is being rehydrated.
   */
  async connect(ws: SocketLike, pageId: string, user: ConnUser, role: Role): Promise<void> {
    const conn = new Conn(user, role);
    const queue: Uint8Array[] = [];
    let room: Room | null = null;
    let closed = false;

    ws.on("message", (raw: unknown) => {
      const data = toU8(raw);
      if (room) this.onMessage(room, ws, conn, data);
      else queue.push(data);
    });
    ws.on("pong", () => (conn.alive = true));
    ws.on("error", (e: Error) => this.log(`socket error: ${e.message}`));
    ws.on("close", () => {
      closed = true;
      if (room) this.onClose(room, ws, conn);
    });

    try {
      room = await this.getRoom(pageId);
    } catch (e) {
      this.log(`failed to open room ${pageId}`, e);
      ws.close(1011, "room unavailable");
      return;
    }
    if (closed) {
      void this.maybeClose(room);
      return;
    }
    room.conns.set(ws, conn);

    this.send(ws, encodeAuth(role));
    const e = encoding.createEncoder();
    encoding.writeVarUint(e, MSG.SYNC);
    syncProtocol.writeSyncStep1(e, room.doc);
    this.send(ws, encoding.toUint8Array(e));
    const ids = [...room.awareness.getStates().keys()];
    if (ids.length) {
      const a = encoding.createEncoder();
      encoding.writeVarUint(a, MSG.AWARENESS);
      encoding.writeVarUint8Array(a, awarenessProtocol.encodeAwarenessUpdate(room.awareness, ids));
      this.send(ws, encoding.toUint8Array(a));
    }
    for (const d of queue.splice(0)) this.onMessage(room, ws, conn, d);
  }

  private onClose(room: Room, ws: SocketLike, conn: Conn) {
    if (!room.conns.delete(ws)) return;
    awarenessProtocol.removeAwarenessStates(room.awareness, [...conn.controlledIds], null);
    void this.maybeClose(room);
  }

  private onMessage(room: Room, ws: SocketLike, conn: Conn, data: Uint8Array) {
    this.metrics.messagesIn++;
    // ---- RBAC at the WebSocket level -------------------------------------------------
    const auth = authorizeClientMessage(conn.role, data);
    if (!auth.ok) {
      this.metrics.rejected++;
      const info = inspectMessage(data);
      if (info && isDocMutation(info)) this.send(ws, encodeDenied(auth.reason));
      return;
    }
    try {
      const dec = decoding.createDecoder(data);
      const type = decoding.readVarUint(dec);
      if (type === MSG.SYNC) {
        const enc = encoding.createEncoder();
        encoding.writeVarUint(enc, MSG.SYNC);
        syncProtocol.readSyncMessage(dec, enc, room.doc, conn);
        if (encoding.length(enc) > 1) this.send(ws, encoding.toUint8Array(enc));
      } else if (type === MSG.AWARENESS) {
        awarenessProtocol.applyAwarenessUpdate(room.awareness, decoding.readVarUint8Array(dec), conn);
      }
    } catch (err) {
      this.log("bad message", err);
    }
  }

  private send(ws: SocketLike, msg: Uint8Array) {
    if (ws.readyState !== OPEN) return;
    try {
      ws.send(msg, (err) => {
        if (err) ws.close();
      });
    } catch {
      ws.close();
    }
  }

  private beat() {
    for (const room of this.ready.values()) {
      for (const [ws, conn] of room.conns) {
        if (!ws.ping) continue;
        if (!conn.alive) {
          ws.terminate?.();
          continue;
        }
        conn.alive = false;
        try {
          ws.ping();
        } catch {
          ws.terminate?.();
        }
      }
    }
  }

  /* --------------------------- doc / awareness fan-out ------------------------ */

  private publish(room: Room, kind: number, payload: Uint8Array) {
    this.opts.bus.publish(docChannel(room.pageId), encodeBus(this.id, kind, payload));
  }

  private onDocUpdate(room: Room, update: Uint8Array, origin: unknown) {
    const e = encoding.createEncoder();
    encoding.writeVarUint(e, MSG.SYNC);
    syncProtocol.writeUpdate(e, update);
    const msg = encoding.toUint8Array(e);
    for (const [ws, conn] of room.conns) if (origin !== conn) this.send(ws, msg);

    if (origin !== "redis" && origin !== "db") this.publish(room, BUS.UPDATE, update);
    if (origin !== "db") {
      room.changedSinceSnapshot = true;
      this.markDirty(room);
    }
  }

  private onAwarenessUpdate(
    room: Room,
    { added, updated, removed }: { added: number[]; updated: number[]; removed: number[] },
    origin: unknown
  ) {
    if (origin instanceof Conn) {
      added.forEach((id) => origin.controlledIds.add(id));
      removed.forEach((id) => origin.controlledIds.delete(id));
    }
    const changed = added.concat(updated, removed);
    const update = awarenessProtocol.encodeAwarenessUpdate(room.awareness, changed);
    const e = encoding.createEncoder();
    encoding.writeVarUint(e, MSG.AWARENESS);
    encoding.writeVarUint8Array(e, update);
    const msg = encoding.toUint8Array(e);
    for (const ws of room.conns.keys()) this.send(ws, msg);
    if (origin !== "redis") this.publish(room, BUS.AWARENESS, update);
  }

  private onBus(room: Room, data: Uint8Array) {
    let m;
    try {
      m = decodeBus(data);
    } catch {
      return;
    }
    if (m.instanceId === this.id) return; // our own echo
    this.metrics.updatesFromBus++;
    switch (m.kind) {
      case BUS.UPDATE:
        Y.applyUpdate(room.doc, m.payload, "redis");
        break;
      case BUS.AWARENESS:
        awarenessProtocol.applyAwarenessUpdate(room.awareness, m.payload, "redis");
        break;
      case BUS.AWARENESS_QUERY: {
        const ids = [...room.awareness.getStates().keys()];
        if (ids.length) this.publish(room, BUS.AWARENESS, awarenessProtocol.encodeAwarenessUpdate(room.awareness, ids));
        break;
      }
      case BUS.SYNC_REQUEST: {
        const diff = Y.encodeStateAsUpdate(room.doc, m.payload);
        if (diff.length > 2) this.publish(room, BUS.UPDATE, diff);
        break;
      }
    }
  }

  /* ------------------------------- persistence ------------------------------- */

  private markDirty(room: Room) {
    room.dirty = true;
    if (!room.saveTimer) {
      room.saveTimer = setTimeout(() => void this.flush(room), this.saveMs);
    }
  }

  /** Persist Y.encodeStateAsUpdate(doc). Saves are serialised per room. */
  flush(room: Room, o: { snapshot?: boolean } = {}): Promise<void> {
    if (room.saveTimer) {
      clearTimeout(room.saveTimer);
      room.saveTimer = null;
    }
    room.saveChain = room.saveChain.then(async () => {
      if (!room.dirty) return;
      room.dirty = false;
      const state = Y.encodeStateAsUpdate(room.doc);
      try {
        await this.opts.store.save(room.pageId, state);
        this.metrics.saves++;
        const due = Date.now() - room.lastSnapshotAt >= this.snapMs;
        if (room.changedSinceSnapshot && (o.snapshot || due)) {
          await this.opts.store.snapshot(room.pageId, state);
          this.metrics.snapshots++;
          room.changedSinceSnapshot = false;
          room.lastSnapshotAt = Date.now();
        }
      } catch (e) {
        room.dirty = true;
        this.log(`save failed for ${room.pageId}`, e);
        if (!room.saveTimer) room.saveTimer = setTimeout(() => void this.flush(room), this.saveMs);
      }
    });
    return room.saveChain;
  }

  /* ------------------------------ control plane ------------------------------ */

  hasRoom(pageId: string): boolean {
    return this.ready.has(pageId);
  }

  async flushRoom(pageId: string): Promise<boolean> {
    const room = this.ready.get(pageId);
    if (!room) return false;
    await this.flush(room);
    return true;
  }

  /** Apply a snapshot restore to the live document (replicates to all clients and instances). */
  async restore(pageId: string, snapshotState: Uint8Array): Promise<boolean> {
    const room = this.ready.get(pageId);
    if (!room) return false;
    restoreSnapshot(room.doc, snapshotState, "restore");
    await this.flush(room);
    return true;
  }

  /** Re-evaluate every connection's role (after the Share modal changed something). */
  async refreshRoles(pageId: string, resolve: (userId: string) => Promise<Role | null>): Promise<void> {
    const room = this.ready.get(pageId);
    if (!room) return;
    for (const [ws, conn] of [...room.conns]) {
      const role = await resolve(conn.user.id);
      if (!role) {
        ws.close(4403, "access revoked");
      } else if (role !== conn.role) {
        conn.role = role;
        this.send(ws, encodeAuth(role));
      }
    }
  }

  getDoc(pageId: string): Y.Doc | undefined {
    return this.ready.get(pageId)?.doc;
  }

  stats() {
    let connections = 0;
    for (const r of this.ready.values()) connections += r.conns.size;
    const m = process.memoryUsage();
    return {
      instanceId: this.id,
      rooms: this.ready.size,
      connections,
      rssMb: Math.round(m.rss / 1048576),
      heapUsedMb: Math.round(m.heapUsed / 1048576),
      ...this.metrics,
    };
  }

  async shutdown() {
    if (this.heartbeat) clearInterval(this.heartbeat);
    await Promise.all([...this.ready.values()].map((r) => this.flush(r, { snapshot: true })));
  }
}
