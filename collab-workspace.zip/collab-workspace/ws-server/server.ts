import "dotenv/config";
import http from "node:http";
import { randomUUID } from "node:crypto";
import { PrismaClient } from "@prisma/client";
import Redis from "ioredis";
import { WebSocketServer, WebSocket } from "ws";
import { COOKIE_NAME, parseCookie, verifyToken } from "../shared/auth-token";
import { getPageAccess } from "../shared/access";
import { CTL_CHANNEL } from "../shared/protocol";
import { Role } from "../shared/rbac";
import { PrismaStore, RedisBus } from "./adapters";
import { RoomManager, SocketLike } from "./room";

const PORT = Number(process.env.PORT ?? 4001);
const INSTANCE_ID = process.env.INSTANCE_ID ?? `ws-${PORT}-${randomUUID().slice(0, 6)}`;
const REDIS_URL = process.env.REDIS_URL ?? "redis://localhost:6379";
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS ?? "http://localhost:3000").split(",").map((s) => s.trim());

const log = (msg: string, extra?: unknown) =>
  console.log(`[${new Date().toISOString()}] [${INSTANCE_ID}] ${msg}`, extra ?? "");

const prisma = new PrismaClient();
const bus = new RedisBus(REDIS_URL);
const redis = bus.publisher;

const manager = new RoomManager({
  instanceId: INSTANCE_ID,
  store: new PrismaStore(prisma),
  bus,
  log,
  onRoomOpen: (pageId) => void redis.sadd(`rooms:${pageId}`, INSTANCE_ID).catch(() => {}),
  onRoomClose: (pageId) => void redis.srem(`rooms:${pageId}`, INSTANCE_ID).catch(() => {}),
});

/* --------------------------- control plane (Redis) -------------------------- */
// The REST API (Next.js) cannot touch live in-memory documents, so it sends commands here.
// Every instance receives them; only instances that currently host the room act.

type Ctl =
  | { type: "refresh-perms"; pageId: string; opId: string }
  | { type: "flush"; pageId: string; opId: string }
  | { type: "restore"; pageId: string; versionId: string; opId: string };

const ctlSub = new Redis(REDIS_URL, { maxRetriesPerRequest: null });
void ctlSub.subscribe(CTL_CHANNEL);
ctlSub.on("message", async (_ch, raw) => {
  let msg: Ctl;
  try {
    msg = JSON.parse(raw);
  } catch {
    return;
  }
  if (!manager.hasRoom(msg.pageId)) return;
  try {
    if (msg.type === "refresh-perms") {
      await manager.refreshRoles(msg.pageId, async (userId) => {
        const a = await getPageAccess(prisma, userId, msg.pageId);
        return (a?.role as Role | null) ?? null;
      });
    } else if (msg.type === "flush") {
      await manager.flushRoom(msg.pageId);
      await redis.set(`ack:${msg.opId}`, INSTANCE_ID, "EX", 30);
    } else if (msg.type === "restore") {
      // exactly one instance applies the restore; the result replicates through Redis
      const won = await redis.set(`lock:${msg.opId}`, INSTANCE_ID, "EX", 30, "NX");
      if (won !== "OK") return;
      const v = await prisma.pageVersion.findUnique({ where: { id: msg.versionId }, select: { state: true, pageId: true } });
      if (!v || v.pageId !== msg.pageId) return;
      await manager.restore(msg.pageId, new Uint8Array(v.state));
      await redis.set(`ack:${msg.opId}`, INSTANCE_ID, "EX", 30);
      log(`restored ${msg.pageId} from ${msg.versionId}`);
    }
  } catch (e) {
    log("ctl error", e);
  }
});

/* ------------------------------- HTTP + upgrade ------------------------------ */

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(manager.stats()));
    return;
  }
  res.writeHead(426);
  res.end("Upgrade Required");
});

const wss = new WebSocketServer({ noServer: true, maxPayload: 16 * 1024 * 1024 });

function reject(socket: import("node:stream").Duplex, code: number, text: string) {
  socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\n\r\n`);
  socket.destroy();
}

server.on("upgrade", async (req, socket, head) => {
  try {
    const origin = req.headers.origin;
    if (origin && !ALLOWED_ORIGINS.includes(origin)) return reject(socket, 403, "Forbidden");

    const pageId = decodeURIComponent((req.url ?? "/").split("?")[0].slice(1));
    if (!pageId) return reject(socket, 404, "Not Found");

    const token = parseCookie(req.headers.cookie, COOKIE_NAME);
    const user = await verifyToken(token);
    if (!user) return reject(socket, 401, "Unauthorized");

    const access = await getPageAccess(prisma, user.sub, pageId);
    if (!access) return reject(socket, 404, "Not Found");
    if (!access.role) return reject(socket, 403, "Forbidden");
    const role = access.role as Role;

    wss.handleUpgrade(req, socket, head, (ws: WebSocket) => {
      // attach listeners synchronously (inside connect) so no early message is lost
      void manager.connect(ws as unknown as SocketLike, pageId, { id: user.sub, name: user.name }, role);
    });
  } catch (e) {
    log("upgrade error", e);
    reject(socket, 500, "Internal Server Error");
  }
});

server.listen(PORT, () => log(`WebSocket server listening on :${PORT}`));

async function shutdown() {
  log("shutting down: flushing rooms");
  await manager.shutdown();
  wss.close();
  server.close();
  await bus.close();
  ctlSub.disconnect();
  await prisma.$disconnect();
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
